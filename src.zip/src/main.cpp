#include "uci.h"
#include <iostream>

int main(int argc, char* argv[]) {
    // Fast I/O
    std::ios_base::sync_with_stdio(false);
    std::cin.tie(NULL);

    uci_loop(argc, argv);
    return 0;
}
