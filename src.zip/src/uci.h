#ifndef UCI_H
#define UCI_H

#include <string>

void uci_loop(int argc, char* argv[]);

#endif // UCI_H
