#include "zobrist.h"

Key PIECE_KEYS[PIECE_NB][SQUARE_NB];
Key CASTLING_KEYS[16];
Key EN_PASSANT_KEYS[8];
Key SIDE_KEY;

static uint64_t splitmix64(uint64_t& state) {
    uint64_t z = (state += 0x9e3779b97f4a7c15ULL);
    z = (z ^ (z >> 30)) * 0xbf58476d1ce4e5b9ULL;
    z = (z ^ (z >> 27)) * 0x94d049bb133111ebULL;
    return z ^ (z >> 31);
}

void init_zobrist() {
    static bool initialized = false;
    if (initialized) return;
    initialized = true;

    uint64_t state = 1070372ULL;

    for (int p = 0; p < PIECE_NB; ++p) {
        for (int sq = 0; sq < SQUARE_NB; ++sq) {
            PIECE_KEYS[p][sq] = splitmix64(state);
        }
    }

    for (int i = 0; i < 16; ++i) {
        CASTLING_KEYS[i] = splitmix64(state);
    }

    for (int f = 0; f < 8; ++f) {
        EN_PASSANT_KEYS[f] = splitmix64(state);
    }

    SIDE_KEY = splitmix64(state);
}
