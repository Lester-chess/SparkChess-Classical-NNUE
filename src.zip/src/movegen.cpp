#include "movegen.h"

void generate_moves(const Board& board, MoveList& list, GenType type) {
    Color us = board.turn();
    Color them = ~us;
    Bitboard us_bb = board.pieces(us);
    Bitboard them_bb = board.pieces(them);
    Bitboard occ = us_bb | them_bb;
    Bitboard empty = ~occ;

    Bitboard target_mask = (type == GEN_CAPTURES) ? them_bb : ~us_bb;

    // 1. Pawn Moves
    Bitboard pawns = board.pieces(us, PAWN);
    Square ep_sq = board.en_passant();

    if (us == WHITE) {
        while (pawns) {
            Square from = pop_lsb(pawns);
            Square single = static_cast<Square>(from + 8);

            // Forward moves (only if GEN_ALL or promotion)
            if (test_bit(empty, single)) {
                if (rank_of(from) == 6) { // Promotion
                    list.add(Move(from, single, FLAG_PROMOTION, QUEEN));
                    list.add(Move(from, single, FLAG_PROMOTION, ROOK));
                    list.add(Move(from, single, FLAG_PROMOTION, BISHOP));
                    list.add(Move(from, single, FLAG_PROMOTION, KNIGHT));
                } else if (type == GEN_ALL) {
                    list.add(Move(from, single, FLAG_NORMAL));
                    if (rank_of(from) == 1) { // Double push
                        Square dbl = static_cast<Square>(from + 16);
                        if (test_bit(empty, dbl)) {
                            list.add(Move(from, dbl, FLAG_NORMAL));
                        }
                    }
                }
            }

            // Captures
            Bitboard attacks = pawn_attacks(WHITE, from) & them_bb;
            while (attacks) {
                Square to = pop_lsb(attacks);
                if (rank_of(from) == 6) { // Promotion capture
                    list.add(Move(from, to, FLAG_PROMOTION, QUEEN));
                    list.add(Move(from, to, FLAG_PROMOTION, ROOK));
                    list.add(Move(from, to, FLAG_PROMOTION, BISHOP));
                    list.add(Move(from, to, FLAG_PROMOTION, KNIGHT));
                } else {
                    list.add(Move(from, to, FLAG_NORMAL));
                }
            }

            // En passant capture
            if (ep_sq != SQ_NONE && test_bit(pawn_attacks(WHITE, from), ep_sq)) {
                list.add(Move(from, ep_sq, FLAG_EN_PASSANT));
            }
        }
    } else { // BLACK
        while (pawns) {
            Square from = pop_lsb(pawns);
            Square single = static_cast<Square>(from - 8);

            if (test_bit(empty, single)) {
                if (rank_of(from) == 1) { // Promotion
                    list.add(Move(from, single, FLAG_PROMOTION, QUEEN));
                    list.add(Move(from, single, FLAG_PROMOTION, ROOK));
                    list.add(Move(from, single, FLAG_PROMOTION, BISHOP));
                    list.add(Move(from, single, FLAG_PROMOTION, KNIGHT));
                } else if (type == GEN_ALL) {
                    list.add(Move(from, single, FLAG_NORMAL));
                    if (rank_of(from) == 6) { // Double push
                        Square dbl = static_cast<Square>(from - 16);
                        if (test_bit(empty, dbl)) {
                            list.add(Move(from, dbl, FLAG_NORMAL));
                        }
                    }
                }
            }

            // Captures
            Bitboard attacks = pawn_attacks(BLACK, from) & them_bb;
            while (attacks) {
                Square to = pop_lsb(attacks);
                if (rank_of(from) == 1) { // Promotion capture
                    list.add(Move(from, to, FLAG_PROMOTION, QUEEN));
                    list.add(Move(from, to, FLAG_PROMOTION, ROOK));
                    list.add(Move(from, to, FLAG_PROMOTION, BISHOP));
                    list.add(Move(from, to, FLAG_PROMOTION, KNIGHT));
                } else {
                    list.add(Move(from, to, FLAG_NORMAL));
                }
            }

            // En passant capture
            if (ep_sq != SQ_NONE && test_bit(pawn_attacks(BLACK, from), ep_sq)) {
                list.add(Move(from, ep_sq, FLAG_EN_PASSANT));
            }
        }
    }

    // 2. Knights
    Bitboard knights = board.pieces(us, KNIGHT);
    while (knights) {
        Square from = pop_lsb(knights);
        Bitboard attacks = knight_attacks(from) & target_mask;
        while (attacks) {
            Square to = pop_lsb(attacks);
            list.add(Move(from, to, FLAG_NORMAL));
        }
    }

    // 3. Bishops
    Bitboard bishops = board.pieces(us, BISHOP);
    while (bishops) {
        Square from = pop_lsb(bishops);
        Bitboard attacks = bishop_attacks(from, occ) & target_mask;
        while (attacks) {
            Square to = pop_lsb(attacks);
            list.add(Move(from, to, FLAG_NORMAL));
        }
    }

    // 4. Rooks
    Bitboard rooks = board.pieces(us, ROOK);
    while (rooks) {
        Square from = pop_lsb(rooks);
        Bitboard attacks = rook_attacks(from, occ) & target_mask;
        while (attacks) {
            Square to = pop_lsb(attacks);
            list.add(Move(from, to, FLAG_NORMAL));
        }
    }

    // 5. Queens
    Bitboard queens = board.pieces(us, QUEEN);
    while (queens) {
        Square from = pop_lsb(queens);
        Bitboard attacks = queen_attacks(from, occ) & target_mask;
        while (attacks) {
            Square to = pop_lsb(attacks);
            list.add(Move(from, to, FLAG_NORMAL));
        }
    }

    // 6. King normal moves
    Square king_sq = board.king_square(us);
    Bitboard k_attacks = king_attacks(king_sq) & target_mask;
    while (k_attacks) {
        Square to = pop_lsb(k_attacks);
        list.add(Move(king_sq, to, FLAG_NORMAL));
    }

    // 7. Castling moves (only in GEN_ALL and when not in check)
    if (type == GEN_ALL && !board.is_in_check(us)) {
        uint8_t cr = board.castling();
        if (us == WHITE) {
            if (cr & WHITE_OO) {
                if (!test_bit(occ, SQ_F1) && !test_bit(occ, SQ_G1)) {
                    if (!board.is_square_attacked(SQ_F1, BLACK) && !board.is_square_attacked(SQ_G1, BLACK)) {
                        list.add(Move(SQ_E1, SQ_G1, FLAG_CASTLING));
                    }
                }
            }
            if (cr & WHITE_OOO) {
                if (!test_bit(occ, SQ_B1) && !test_bit(occ, SQ_C1) && !test_bit(occ, SQ_D1)) {
                    if (!board.is_square_attacked(SQ_D1, BLACK) && !board.is_square_attacked(SQ_C1, BLACK)) {
                        list.add(Move(SQ_E1, SQ_C1, FLAG_CASTLING));
                    }
                }
            }
        } else {
            if (cr & BLACK_OO) {
                if (!test_bit(occ, SQ_F8) && !test_bit(occ, SQ_G8)) {
                    if (!board.is_square_attacked(SQ_F8, WHITE) && !board.is_square_attacked(SQ_G8, WHITE)) {
                        list.add(Move(SQ_E8, SQ_G8, FLAG_CASTLING));
                    }
                }
            }
            if (cr & BLACK_OOO) {
                if (!test_bit(occ, SQ_B8) && !test_bit(occ, SQ_C8) && !test_bit(occ, SQ_D8)) {
                    if (!board.is_square_attacked(SQ_D8, WHITE) && !board.is_square_attacked(SQ_C8, WHITE)) {
                        list.add(Move(SQ_E8, SQ_C8, FLAG_CASTLING));
                    }
                }
            }
        }
    }
}

void generate_legal_moves(Board& board, MoveList& list) {
    MoveList pseudo_moves;
    generate_moves(board, pseudo_moves, GEN_ALL);
    list.clear();
    for (int i = 0; i < pseudo_moves.size; ++i) {
        if (board.make_move(pseudo_moves.moves[i])) {
            list.add(pseudo_moves.moves[i]);
            board.unmake_move(pseudo_moves.moves[i]);
        }
    }
}
