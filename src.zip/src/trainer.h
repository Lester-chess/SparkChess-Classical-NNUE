#ifndef TRAINER_H
#define TRAINER_H

#include "types.h"
#include "board.h"
#include <vector>
#include <string>

struct TrainingSample {
    std::vector<int> features_w;
    std::vector<int> features_b;
    Color turn;
    float outcome; // 1.0 for White win, 0.5 draw, 0.0 Black win
};

class NNUETrainer {
public:
    NNUETrainer();

    // Data generation and loading
    int generate_selfplay(int num_games, int depth, std::vector<TrainingSample>& dataset);
    int load_pgn(const std::string& pgn_path, std::vector<TrainingSample>& dataset, int max_games = 5000);

    // Training loop
    void train(std::vector<TrainingSample>& dataset, int epochs = 5, int batch_size = 128, float lr = 0.001f, const std::string& output_file = "chess_engine/weights/trained.nnue");

private:
    Move parse_san_move(Board& board, const std::string& san_token);

    std::vector<float> ft_weights; // 768 * 256
    std::vector<float> ft_biases;  // 256
    std::vector<float> out_weights;// 512
    float out_bias = 0.0f;

    // Adam optimizer momentum buffers
    std::vector<float> m_ft_weights, v_ft_weights;
    std::vector<float> m_ft_biases, v_ft_biases;
    std::vector<float> m_out_weights, v_out_weights;
    float m_out_bias = 0.0f, v_out_bias = 0.0f;
};

extern NNUETrainer TRAINER;

#endif // TRAINER_H
