#include "uci.h"
#include "board.h"
#include "movegen.h"
#include "search.h"
#include "evaluate.h"
#include "nnue.h"
#include "tt.h"
#include "trainer.h"
#include "book.h"
#include <iostream>
#include <sstream>
#include <vector>
#include <chrono>

static bool OWN_BOOK = true;
static std::string BOOK_FILE = "book.bin";

static uint64_t run_perft(Board& board, int depth) {
    if (depth == 0) return 1ULL;
    MoveList list;
    generate_moves(board, list, GEN_ALL);
    uint64_t nodes = 0;
    for (int i = 0; i < list.size; ++i) {
        if (!board.make_move(list.moves[i])) continue;
        nodes += run_perft(board, depth - 1);
        board.unmake_move(list.moves[i]);
    }
    return nodes;
}

static void cmd_perft(Board& board, int depth) {
    auto t0 = std::chrono::high_resolution_clock::now();
    MoveList list;
    generate_moves(board, list, GEN_ALL);
    uint64_t total = 0;

    std::cout << "\nPerft testing depth " << depth << "...\n";
    for (int i = 0; i < list.size; ++i) {
        if (!board.make_move(list.moves[i])) continue;
        uint64_t n = (depth > 1) ? run_perft(board, depth - 1) : 1ULL;
        total += n;
        board.unmake_move(list.moves[i]);
        std::cout << list.moves[i].to_uci() << ": " << n << "\n";
    }
    auto t1 = std::chrono::high_resolution_clock::now();
    double ms = std::chrono::duration<double, std::milli>(t1 - t0).count();
    std::cout << "\nTotal nodes: " << total << " (" << ms << " ms)\n\n";
}

static void cmd_eval(const Board& board) {
    int c_eval = evaluate_classical(board);
    int n_eval = evaluate_nnue(board);
    std::cout << "\nEvaluation Breakdown:\n";
    std::cout << "-------------------------------------\n";
    std::cout << "Side to move: " << (board.turn() == WHITE ? "White" : "Black") << "\n";
    std::cout << "Classical Eval : " << c_eval << " cp (" << (c_eval / 100.0) << " pawns)\n";
    std::cout << "NNUE Eval      : " << n_eval << " cp (" << (n_eval / 100.0) << " pawns)\n";
    std::cout << "Current Mode   : ";
    switch (get_eval_mode()) {
        case EVAL_CLASSICAL: std::cout << "Classical\n"; break;
        case EVAL_NNUE:      std::cout << "NNUE\n"; break;
        case EVAL_HYBRID:    std::cout << "Hybrid\n"; break;
    }
    std::cout << "Active Score   : " << evaluate(board) << " cp\n\n";
}

void uci_loop(int argc, char* argv[]) {
    init_bitboards();
    init_zobrist();
    init_default_nnue();
    init_polyglot();

    Board board(START_FEN);
    std::string line;

    if (argc > 1) {
        std::string arg1 = argv[1];
        if (arg1 == "bench") {
            int d = (argc > 2) ? std::stoi(argv[2]) : 6;
            SEARCHER.bench(d);
            return;
        }
    }

    while (std::getline(std::cin, line)) {
        if (line.empty()) continue;
        std::istringstream ss(line);
        std::string token;
        ss >> token;

        if (token == "uci") {
            std::cout << "id name SparkChess 1.0\n";
            std::cout << "id author SparkChess Team\n";
            std::cout << "option name Hash type spin default 16 min 1 max 1024\n";
            std::cout << "option name Threads type spin default 1 min 1 max 64\n";
            std::cout << "option name EvalMode type combo default NNUE var Classical var NNUE var Hybrid\n";
            std::cout << "option name NNUEFile type string default weights/sparkchess.nnue\n";
            std::cout << "option name OwnBook type check default true\n";
            std::cout << "option name BookFile type string default book.bin\n";
            std::cout << "uciok\n";
            std::cout.flush();
        } else if (token == "isready") {
            std::cout << "readyok\n";
            std::cout.flush();
        } else if (token == "ucinewgame") {
            TT.clear();
            board.set_fen(START_FEN);
        } else if (token == "setoption") {
            std::string name_tok, option_name, val_tok, option_value;
            ss >> name_tok;
            if (name_tok == "name") {
                ss >> option_name;
                while (ss >> val_tok && val_tok != "value") {
                    option_name += " " + val_tok;
                }
                if (val_tok == "value") {
                    ss >> option_value;
                    std::string rest;
                    if (std::getline(ss, rest)) {
                        while (!rest.empty() && rest[0] == ' ') rest.erase(0, 1);
                        if (!rest.empty()) option_value += " " + rest;
                    }
                }

                if (option_name == "Hash") {
                    TT.resize(std::stoi(option_value));
                } else if (option_name == "Threads") {
                    SEARCHER.set_threads(std::stoi(option_value));
                } else if (option_name == "EvalMode") {
                    if (option_value == "Classical") set_eval_mode(EVAL_CLASSICAL);
                    else if (option_value == "NNUE") set_eval_mode(EVAL_NNUE);
                    else if (option_value == "Hybrid") set_eval_mode(EVAL_HYBRID);
                } else if (option_name == "NNUEFile") {
                    load_nnue(option_value);
                } else if (option_name == "OwnBook") {
                    OWN_BOOK = (option_value == "true" || option_value == "1");
                } else if (option_name == "BookFile") {
                    BOOK_FILE = option_value;
                }
            }
        } else if (token == "position") {
            std::string pos_type;
            ss >> pos_type;
            if (pos_type == "startpos") {
                board.set_fen(START_FEN);
                std::string moves_tok;
                if (ss >> moves_tok && moves_tok == "moves") {
                    std::string m_str;
                    while (ss >> m_str) {
                        MoveList legal;
                        generate_legal_moves(board, legal);
                        for (int i = 0; i < legal.size; ++i) {
                            if (legal.moves[i].to_uci() == m_str) {
                                board.make_move(legal.moves[i]);
                                break;
                            }
                        }
                    }
                }
            } else if (pos_type == "fen") {
                std::string fen_str, part;
                for (int i = 0; i < 6 && ss >> part; ++i) {
                    if (part == "moves") break;
                    if (i > 0) fen_str += " ";
                    fen_str += part;
                }
                board.set_fen(fen_str);
                if (part == "moves" || ss >> part) {
                    std::string m_str;
                    while (ss >> m_str) {
                        MoveList legal;
                        generate_legal_moves(board, legal);
                        for (int i = 0; i < legal.size; ++i) {
                            if (legal.moves[i].to_uci() == m_str) {
                                board.make_move(legal.moves[i]);
                                break;
                            }
                        }
                    }
                }
            }
        } else if (token == "go") {
            // First check opening book if enabled
            if (OWN_BOOK) {
                Move book_move = probe_book(board, BOOK_FILE, true);
                if (!book_move.is_null()) {
                    std::cout << "info string Book move found\n";
                    std::cout << "bestmove " << book_move.to_uci() << std::endl;
                    continue;
                }
            }

            SearchLimits limits;
            bool has_limit = false;
            std::string sub;
            while (ss >> sub) {
                if (sub == "wtime") { ss >> limits.time[WHITE]; has_limit = true; }
                else if (sub == "btime") { ss >> limits.time[BLACK]; has_limit = true; }
                else if (sub == "winc") { ss >> limits.inc[WHITE]; has_limit = true; }
                else if (sub == "binc") { ss >> limits.inc[BLACK]; has_limit = true; }
                else if (sub == "movestogo") { ss >> limits.movestogo; has_limit = true; }
                else if (sub == "depth") { ss >> limits.depth; has_limit = true; }
                else if (sub == "nodes") { ss >> limits.nodes; has_limit = true; }
                else if (sub == "movetime") { ss >> limits.movetime; has_limit = true; }
                else if (sub == "infinite") { limits.infinite = true; has_limit = true; }
            }

            if (!has_limit) {
                limits.depth = 7; // Safe default depth if none specified
            }

            SEARCHER.start_search(board, limits);
        } else if (token == "stop") {
            SEARCHER.stop();
        } else if (token == "d" || token == "display") {
            board.print();
        } else if (token == "eval") {
            cmd_eval(board);
        } else if (token == "bench") {
            int d = 6;
            ss >> d;
            SEARCHER.bench(d);
        } else if (token == "perft") {
            int d = 4;
            ss >> d;
            cmd_perft(board, d);
        } else if (token == "train") {
            std::string mode;
            ss >> mode;
            if (mode == "pgn") {
                std::string pgn_file;
                int epochs = 5;
                int batch_size = 128;
                float lr = 0.001f;
                std::string out_file = "weights/trained.nnue";
                if (ss >> pgn_file) {
                    if (ss >> epochs) {
                        if (ss >> batch_size) {
                            if (ss >> lr) {
                                ss >> out_file;
                            }
                        }
                    }
                    std::vector<TrainingSample> dataset;
                    TRAINER.load_pgn(pgn_file, dataset);
                    TRAINER.train(dataset, epochs, batch_size, lr, out_file);
                }
            } else if (mode == "selfplay") {
                int games = 20, depth = 4, epochs = 5;
                std::string out_file = "weights/trained.nnue";
                ss >> games >> depth >> epochs >> out_file;
                std::vector<TrainingSample> dataset;
                TRAINER.generate_selfplay(games, depth, dataset);
                TRAINER.train(dataset, epochs, 128, 0.001f, out_file);
            }
        } else if (token == "quit") {
            SEARCHER.stop();
            break;
        }
    }
}
