#include "nnue.h"
#include <fstream>
#include <iostream>
#include <cstring>
#include <algorithm>
#include <cmath>

NNUEWeights GLOBAL_NNUE;
bool NNUE_LOADED = false;

struct NNUEHeader {
    char magic[4];       // "NNUE"
    uint32_t version;    // 1
    uint32_t num_inputs; // 768
    uint32_t num_hidden; // 256
    uint32_t num_outputs;// 1
};

bool is_nnue_loaded() {
    return NNUE_LOADED;
}

bool load_nnue(const std::string& filepath) {
    std::ifstream file(filepath, std::ios::binary);
    if (!file.is_open()) {
        std::cerr << "info string Failed to open NNUE file: " << filepath << std::endl;
        return false;
    }

    NNUEHeader header;
    file.read(reinterpret_cast<char*>(&header), sizeof(NNUEHeader));
    if (!file || std::memcmp(header.magic, "NNUE", 4) != 0 || header.version != 1) {
        std::cerr << "info string Invalid NNUE header in file: " << filepath << std::endl;
        return false;
    }

    if (header.num_inputs != NNUE_INPUTS || header.num_hidden != NNUE_HIDDEN || header.num_outputs != NNUE_OUTPUTS) {
        std::cerr << "info string Incompatible NNUE architecture dimensions" << std::endl;
        return false;
    }

    file.read(reinterpret_cast<char*>(GLOBAL_NNUE.ft_biases), sizeof(GLOBAL_NNUE.ft_biases));
    file.read(reinterpret_cast<char*>(GLOBAL_NNUE.ft_weights), sizeof(GLOBAL_NNUE.ft_weights));
    file.read(reinterpret_cast<char*>(&GLOBAL_NNUE.out_bias), sizeof(GLOBAL_NNUE.out_bias));
    file.read(reinterpret_cast<char*>(GLOBAL_NNUE.out_weights), sizeof(GLOBAL_NNUE.out_weights));

    if (!file) {
        std::cerr << "info string Corrupt data when reading NNUE weights" << std::endl;
        return false;
    }

    NNUE_LOADED = true;
    std::cout << "info string Successfully loaded NNUE weights from " << filepath << std::endl;
    return true;
}

bool save_nnue(const std::string& filepath) {
    std::ofstream file(filepath, std::ios::binary);
    if (!file.is_open()) {
        std::cerr << "Failed to create NNUE file: " << filepath << std::endl;
        return false;
    }

    NNUEHeader header = { {'N', 'N', 'U', 'E'}, 1, NNUE_INPUTS, NNUE_HIDDEN, NNUE_OUTPUTS };
    file.write(reinterpret_cast<const char*>(&header), sizeof(NNUEHeader));
    file.write(reinterpret_cast<const char*>(GLOBAL_NNUE.ft_biases), sizeof(GLOBAL_NNUE.ft_biases));
    file.write(reinterpret_cast<const char*>(GLOBAL_NNUE.ft_weights), sizeof(GLOBAL_NNUE.ft_weights));
    file.write(reinterpret_cast<const char*>(&GLOBAL_NNUE.out_bias), sizeof(GLOBAL_NNUE.out_bias));
    file.write(reinterpret_cast<const char*>(GLOBAL_NNUE.out_weights), sizeof(GLOBAL_NNUE.out_weights));

    return file.good();
}

void init_default_nnue() {
    // Initialize default weights so NNUE is functional immediately
    for (int i = 0; i < NNUE_HIDDEN; ++i) {
        GLOBAL_NNUE.ft_biases[i] = 16;
    }

    const int PIECE_BASE_VALUES[12] = {
        100, 320, 330, 500, 950, 0,
        -100, -320, -330, -500, -950, 0
    };

    for (int p = 0; p < 12; ++p) {
        for (int sq = 0; sq < 64; ++sq) {
            int feat = p * 64 + sq;
            int base_val = PIECE_BASE_VALUES[p];
            for (int h = 0; h < NNUE_HIDDEN; ++h) {
                // Initialize feature weights with small harmonic variation
                int variation = ((feat * 37 + h * 17) % 15) - 7;
                int w = (base_val / 4) + variation;
                GLOBAL_NNUE.ft_weights[feat * NNUE_HIDDEN + h] = static_cast<int16_t>(std::clamp(w, -2000, 2000));
            }
        }
    }

    GLOBAL_NNUE.out_bias = 0;
    for (int h = 0; h < NNUE_HIDDEN; ++h) {
        GLOBAL_NNUE.out_weights[h] = static_cast<int16_t>(20 + (h % 5));
        GLOBAL_NNUE.out_weights[NNUE_HIDDEN + h] = static_cast<int16_t>(-(20 + (h % 5)));
    }

    NNUE_LOADED = true;
}

int evaluate_nnue(const Board& board) {
    if (!NNUE_LOADED) {
        init_default_nnue();
    }

    int16_t acc_white[NNUE_HIDDEN];
    int16_t acc_black[NNUE_HIDDEN];

    std::memcpy(acc_white, GLOBAL_NNUE.ft_biases, sizeof(acc_white));
    std::memcpy(acc_black, GLOBAL_NNUE.ft_biases, sizeof(acc_black));

    // Refresh accumulator from current board
    for (int sq = 0; sq < SQUARE_NB; ++sq) {
        Piece p = board.piece_at(static_cast<Square>(sq));
        if (p != NO_PIECE) {
            int w_feat = get_feature_index(WHITE, p, static_cast<Square>(sq));
            int b_feat = get_feature_index(BLACK, p, static_cast<Square>(sq));

            const int16_t* w_weights = &GLOBAL_NNUE.ft_weights[w_feat * NNUE_HIDDEN];
            const int16_t* b_weights = &GLOBAL_NNUE.ft_weights[b_feat * NNUE_HIDDEN];

            for (int i = 0; i < NNUE_HIDDEN; ++i) {
                acc_white[i] += w_weights[i];
                acc_black[i] += b_weights[i];
            }
        }
    }

    const int16_t* us_acc = (board.turn() == WHITE) ? acc_white : acc_black;
    const int16_t* them_acc = (board.turn() == WHITE) ? acc_black : acc_white;

    int32_t output = GLOBAL_NNUE.out_bias;

    // Clipped ReLU activation and output layer dot product
    for (int i = 0; i < NNUE_HIDDEN; ++i) {
        int16_t clipped_us = static_cast<int16_t>(std::clamp(static_cast<int>(us_acc[i]), 0, 127));
        output += clipped_us * GLOBAL_NNUE.out_weights[i];

        int16_t clipped_them = static_cast<int16_t>(std::clamp(static_cast<int>(them_acc[i]), 0, 127));
        output += clipped_them * GLOBAL_NNUE.out_weights[NNUE_HIDDEN + i];
    }

    // Scale to standard centipawns
    return output / NNUE_SCALE;
}
