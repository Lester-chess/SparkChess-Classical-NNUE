#include "tt.h"
#include <cstring>
#include <algorithm>

TranspositionTable TT;

TranspositionTable::TranspositionTable() {
    resize(16); // Default 16 MB
}

TranspositionTable::~TranspositionTable() = default;

void TranspositionTable::resize(size_t mb) {
    size_t bytes = mb * 1024 * 1024;
    num_entries = bytes / sizeof(TTEntry);
    table.clear();
    table.resize(num_entries);
    clear();
}

void TranspositionTable::clear() {
    std::fill(table.begin(), table.end(), TTEntry{});
}

bool TranspositionTable::probe(Key key, int depth, int alpha, int beta, int ply, int& out_score, Move& out_move) const {
    if (num_entries == 0) return false;

    size_t index = key % num_entries;
    const TTEntry& entry = table[index];

    if (entry.key == key) {
        out_move = entry.best_move;

        // Check if entry depth is sufficient for cutoff
        if (entry.depth >= depth) {
            int score = entry.score;

            // Mate score adjustment relative to root ply
            if (score > VALUE_MATE_IN_MAX) score -= ply;
            else if (score < -VALUE_MATE_IN_MAX) score += ply;

            if (entry.flag == TT_EXACT) {
                out_score = score;
                return true;
            }
            if (entry.flag == TT_LOWERBOUND && score >= beta) {
                out_score = score;
                return true;
            }
            if (entry.flag == TT_UPPERBOUND && score <= alpha) {
                out_score = score;
                return true;
            }
        }
    }
    return false;
}

void TranspositionTable::store(Key key, int depth, int score, TTFlag flag, int ply, Move best_move) {
    if (num_entries == 0) return;

    size_t index = key % num_entries;
    TTEntry& entry = table[index];

    // Replacement strategy: replace if empty, different key, deeper, or older generation
    if (entry.key == 0 || entry.key != key || depth >= entry.depth || entry.age != current_age) {
        // Mate score adjustment relative to root ply
        if (score > VALUE_MATE_IN_MAX) score += ply;
        else if (score < -VALUE_MATE_IN_MAX) score -= ply;

        entry.key = key;
        entry.depth = static_cast<int8_t>(depth);
        entry.flag = static_cast<uint8_t>(flag);
        entry.score = static_cast<int16_t>(score);
        entry.age = current_age;
        if (!best_move.is_null() || entry.key != key) {
            entry.best_move = best_move;
        }
    }
}

int TranspositionTable::hashfull() const {
    if (num_entries == 0) return 0;
    int sampled = 1000;
    int count = 0;
    for (int i = 0; i < sampled; ++i) {
        if (table[i].key != 0 && table[i].age == current_age) {
            count++;
        }
    }
    return count;
}
