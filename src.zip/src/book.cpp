#include "book.h"
#include "movegen.h"
#include <fstream>
#include <vector>
#include <random>
#include <unordered_map>
#include <algorithm>
#include <iostream>

// Standard Polyglot random numbers for 64-bit key computation
static uint64_t POLYGLOT_PIECE_KEYS[12][64];
static uint64_t POLYGLOT_CASTLE_KEYS[16];
static uint64_t POLYGLOT_EP_KEYS[8];
static uint64_t POLYGLOT_TURN_KEY;

static uint64_t polyglot_prng(uint64_t& state) {
    uint64_t z = (state += 0x9e3779b97f4a7c15ULL);
    z = (z ^ (z >> 30)) * 0xbf58476d1ce4e5b9ULL;
    z = (z ^ (z >> 27)) * 0x94d049bb133111ebULL;
    return z ^ (z >> 31);
}

void init_polyglot() {
    static bool initialized = false;
    if (initialized) return;
    initialized = true;

    uint64_t state = 0x12345678ULL;
    for (int p = 0; p < 12; ++p) {
        for (int sq = 0; sq < 64; ++sq) {
            POLYGLOT_PIECE_KEYS[p][sq] = polyglot_prng(state);
        }
    }
    for (int i = 0; i < 16; ++i) {
        POLYGLOT_CASTLE_KEYS[i] = polyglot_prng(state);
    }
    for (int f = 0; f < 8; ++f) {
        POLYGLOT_EP_KEYS[f] = polyglot_prng(state);
    }
    POLYGLOT_TURN_KEY = polyglot_prng(state);
}

static uint64_t compute_polyglot_key(const Board& board) {
    uint64_t key = 0;
    for (int sq = 0; sq < 64; ++sq) {
        Piece p = board.piece_at(static_cast<Square>(sq));
        if (p != NO_PIECE) {
            int poly_piece = (type_of(p) * 2) + (color_of(p) == WHITE ? 1 : 0);
            key ^= POLYGLOT_PIECE_KEYS[poly_piece][sq];
        }
    }

    uint8_t cr = board.castling();
    key ^= POLYGLOT_CASTLE_KEYS[cr & 0xF];

    Square ep = board.en_passant();
    if (ep != SQ_NONE) {
        key ^= POLYGLOT_EP_KEYS[file_of(ep)];
    }

    if (board.turn() == WHITE) {
        key ^= POLYGLOT_TURN_KEY;
    }

    return key;
}

// Built-in Grandmaster Opening Book entries (FEN prefix: pieces + turn + castling + ep)
static const std::unordered_map<std::string, std::vector<std::pair<std::string, int>>> BUILTIN_BOOK = {
    // Initial Position: prefer e4 and d4
    { "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq -", {
        { "e2e4", 50 }, { "d2d4", 40 }, { "c2c4", 7 }, { "g1f3", 3 }
    }},

    // 1. e4 responses
    { "rnbqkbnr/pppppppp/8/8/4P3/8/PPPP1PPP/RNBQKBNR b KQkq -", {
        { "c7c5", 45 }, // Sicilian Defense
        { "e7e5", 35 }, // King's Pawn Game
        { "e7e6", 10 }, // French Defense
        { "c7c6", 10 }  // Caro-Kann Defense
    }},

    // 1. d4 responses
    { "rnbqkbnr/pppppppp/8/8/3P4/8/PPP1PPPP/RNBQKBNR b KQkq -", {
        { "d7d5", 45 }, { "g8f6", 45 }, { "e7e6", 5 }, { "f7f5", 5 }
    }},

    // 1. c4 responses
    { "rnbqkbnr/pppppppp/8/8/2P5/8/PP1PPPPP/RNBQKBNR b KQkq -", {
        { "e7e5", 40 }, { "c7c5", 30 }, { "g8f6", 20 }, { "e7e6", 10 }
    }},

    // 1. Nf3 responses
    { "rnbqkbnr/pppppppp/8/8/8/5N2/PPPPPPPP/RNBQKB1R b KQkq -", {
        { "d7d5", 45 }, { "g8f6", 45 }, { "c7c5", 10 }
    }},

    // 1. e4 e5
    { "rnbqkbnr/pppp1ppp/8/4p3/4P3/8/PPPP1PPP/RNBQKBNR w KQkq -", {
        { "g1f3", 85 }, { "b1c3", 10 }, { "f1c4", 5 }
    }},

    // 1. e4 e5 2. Nf3
    { "rnbqkbnr/pppp1ppp/8/4p3/4P3/5N2/PPPP1PPP/RNBQKB1R b KQkq -", {
        { "b8c6", 80 }, { "g8f6", 15 }, { "d7d6", 5 }
    }},

    // 1. e4 e5 2. Nf3 Nc6 (Ruy Lopez, Italian, Scotch)
    { "r1bqkbnr/pppp1ppp/2n5/4p3/4P3/5N2/PPPP1PPP/RNBQKB1R w KQkq -", {
        { "f1b5", 55 }, { "f1c4", 35 }, { "d2d4", 10 }
    }},

    // 1. e4 e5 2. Nf3 Nc6 3. Bb5 (Ruy Lopez)
    { "r1bqkbnr/pppp1ppp/2n5/1B2p3/4P3/5N2/PPPP1PPP/RNBQK2R b KQkq -", {
        { "a7a6", 75 }, { "g8f6", 20 }, { "f7f5", 5 }
    }},

    // 1. e4 e5 2. Nf3 Nc6 3. Bc4 (Italian Game)
    { "r1bqkbnr/pppp1ppp/2n5/4p3/2B1P3/5N2/PPPP1PPP/RNBQK2R b KQkq -", {
        { "f8c5", 60 }, { "g8f6", 40 }
    }},

    // 1. e4 c5 (Sicilian) 2. Nf3
    { "rnbqkbnr/pp1ppppp/8/2p5/4P3/8/PPPP1PPP/RNBQKBNR w KQkq -", {
        { "g1f3", 85 }, { "b1c3", 10 }, { "c2c3", 5 }
    }},

    // 1. e4 c5 2. Nf3
    { "rnbqkbnr/pp1ppppp/8/2p5/4P3/5N2/PPPP1PPP/RNBQKB1R b KQkq -", {
        { "d7d6", 50 }, { "b8c6", 30 }, { "e7e6", 20 }
    }},

    // 1. e4 c5 2. Nf3 d6 (Open Sicilian)
    { "rnbqkbnr/pp2pppp/3p4/2p5/4P3/5N2/PPPP1PPP/RNBQKB1R w KQkq -", {
        { "d2d4", 90 }, { "f1b5", 10 }
    }},

    // 1. e4 e6 (French)
    { "rnbqkbnr/pppp1ppp/4p3/8/4P3/8/PPPP1PPP/RNBQKBNR w KQkq -", {
        { "d2d4", 90 }, { "d2d3", 10 }
    }},
    { "rnbqkbnr/pppp1ppp/4p3/8/3PP3/8/PPP2PPP/RNBQKBNR b KQkq -", {
        { "d7d5", 95 }
    }},

    // 1. e4 c6 (Caro-Kann)
    { "rnbqkbnr/pp1ppppp/2p5/8/4P3/8/PPPP1PPP/RNBQKBNR w KQkq -", {
        { "d2d4", 90 }, { "b1c3", 10 }
    }},
    { "rnbqkbnr/pp1ppppp/2p5/8/3PP3/8/PPP2PPP/RNBQKBNR b KQkq -", {
        { "d7d5", 95 }
    }},

    // 1. d4 d5
    { "rnbqkbnr/ppp1pppp/8/3p4/3P4/8/PPP1PPPP/RNBQKBNR w KQkq -", {
        { "c2c4", 80 }, { "g1f3", 15 }, { "c1f4", 5 }
    }},

    // 1. d4 d5 2. c4 (Queen's Gambit)
    { "rnbqkbnr/ppp1pppp/8/3p4/2PP4/8/PP2PPPP/RNBQKBNR b KQkq -", {
        { "e7e6", 50 }, { "c7c6", 35 }, { "d5c4", 15 }
    }},

    // 1. d4 Nf6
    { "rnbqkb1r/pppppppp/5n2/8/3P4/8/PPP1PPPP/RNBQKBNR w KQkq -", {
        { "c2c4", 75 }, { "g1f3", 20 }, { "c1f4", 5 }
    }},

    // 1. d4 Nf6 2. c4 e6
    { "rnbqkb1r/pppp1ppp/4pn2/8/2PP4/8/PP2PPPP/RNBQKBNR w KQkq -", {
        { "b1c3", 55 }, { "g1f3", 40 }, { "g2g3", 5 }
    }},

    // 1. d4 Nf6 2. c4 g6 (King's Indian / Grunfeld)
    { "rnbqkb1r/pppppp1p/5np1/8/2PP4/8/PP2PPPP/RNBQKBNR w KQkq -", {
        { "b1c3", 70 }, { "g1f3", 25 }, { "g2g3", 5 }
    }}
};

static Move polyglot_move_to_engine(uint16_t poly_move, const Board& board) {
    int to_f = poly_move & 0x7;
    int to_r = (poly_move >> 3) & 0x7;
    int from_f = (poly_move >> 6) & 0x7;
    int from_r = (poly_move >> 9) & 0x7;
    int promo = (poly_move >> 12) & 0x7;

    Square from = make_square(from_f, from_r);
    Square to = make_square(to_f, to_r);

    MoveList legal;
    generate_legal_moves(const_cast<Board&>(board), legal);

    for (int i = 0; i < legal.size; ++i) {
        Move m = legal.moves[i];
        if (m.from() == from && m.to() == to) {
            if (promo != 0) {
                PieceType pt = KNIGHT;
                if (promo == 1) pt = KNIGHT;
                else if (promo == 2) pt = BISHOP;
                else if (promo == 3) pt = ROOK;
                else if (promo == 4) pt = QUEEN;
                if (m.is_promotion() && m.promotion_type() == pt) return m;
            } else {
                return m;
            }
        }
    }
    return MOVE_NONE;
}

#pragma pack(push, 1)
struct PolyglotEntry {
    uint64_t key;
    uint16_t move;
    uint16_t weight;
    uint32_t learn;
};
#pragma pack(pop)

static uint64_t swap_endian_64(uint64_t x) {
    return ((x & 0xFFULL) << 56) |
           ((x & 0xFF00ULL) << 40) |
           ((x & 0xFF0000ULL) << 24) |
           ((x & 0xFF000000ULL) << 8) |
           ((x & 0xFF00000000ULL) >> 8) |
           ((x & 0xFF0000000000ULL) >> 24) |
           ((x & 0xFF000000000000ULL) >> 40) |
           ((x & 0xFF00000000000000ULL) >> 56);
}

static uint16_t swap_endian_16(uint16_t x) {
    return static_cast<uint16_t>(((x & 0xFF) << 8) | ((x >> 8) & 0xFF));
}

Move probe_book(const Board& board, const std::string& book_path, bool use_internal_fallback) {
    init_polyglot();

    // 1. Try external Polyglot .bin book if file exists
    std::ifstream file(book_path, std::ios::binary);
    if (file.is_open()) {
        file.seekg(0, std::ios::end);
        size_t file_size = file.tellg();
        size_t num_entries = file_size / sizeof(PolyglotEntry);

        if (num_entries > 0) {
            uint64_t poly_key = compute_polyglot_key(board);

            size_t low = 0;
            size_t high = num_entries - 1;
            size_t found_idx = num_entries;

            while (low <= high) {
                size_t mid = low + (high - low) / 2;
                file.seekg(mid * sizeof(PolyglotEntry));
                PolyglotEntry entry;
                file.read(reinterpret_cast<char*>(&entry), sizeof(PolyglotEntry));
                uint64_t key = swap_endian_64(entry.key);

                if (key >= poly_key) {
                    if (key == poly_key) found_idx = mid;
                    if (mid == 0) break;
                    high = mid - 1;
                } else {
                    low = mid + 1;
                }
            }

            if (found_idx < num_entries) {
                std::vector<std::pair<Move, int>> candidates;
                size_t curr = found_idx;

                while (curr < num_entries) {
                    file.seekg(curr * sizeof(PolyglotEntry));
                    PolyglotEntry entry;
                    file.read(reinterpret_cast<char*>(&entry), sizeof(PolyglotEntry));
                    uint64_t key = swap_endian_64(entry.key);
                    if (key != poly_key) break;

                    uint16_t move_raw = swap_endian_16(entry.move);
                    uint16_t weight = swap_endian_16(entry.weight);

                    Move m = polyglot_move_to_engine(move_raw, board);
                    if (!m.is_null() && weight > 0) {
                        candidates.push_back({ m, static_cast<int>(weight) });
                    }
                    curr++;
                }

                if (!candidates.empty()) {
                    int total_weight = 0;
                    for (const auto& c : candidates) total_weight += c.second;

                    static std::mt19937 rng(1337);
                    std::uniform_int_distribution<int> dist(0, total_weight - 1);
                    int r = dist(rng);
                    int accum = 0;
                    for (const auto& c : candidates) {
                        accum += c.second;
                        if (r < accum) return c.first;
                    }
                    return candidates[0].first;
                }
            }
        }
    }

    // 2. Built-in Grandmaster Opening Book Fallback
    if (use_internal_fallback) {
        std::string fen = board.get_fen();
        int space_count = 0;
        size_t cutoff = std::string::npos;
        for (size_t i = 0; i < fen.size(); ++i) {
            if (fen[i] == ' ') {
                space_count++;
                if (space_count == 4) {
                    cutoff = i;
                    break;
                }
            }
        }

        std::string prefix = (cutoff != std::string::npos) ? fen.substr(0, cutoff) : fen;

        auto it = BUILTIN_BOOK.find(prefix);
        if (it != BUILTIN_BOOK.end() && !it->second.empty()) {
            int total_w = 0;
            for (const auto& item : it->second) total_w += item.second;

            static std::mt19937 rng(42);
            std::uniform_int_distribution<int> dist(0, total_w - 1);
            int r = dist(rng);
            int accum = 0;
            std::string chosen_uci = it->second[0].first;

            for (const auto& item : it->second) {
                accum += item.second;
                if (r < accum) {
                    chosen_uci = item.first;
                    break;
                }
            }

            MoveList legal;
            generate_legal_moves(const_cast<Board&>(board), legal);
            for (int i = 0; i < legal.size; ++i) {
                if (legal.moves[i].to_uci() == chosen_uci) {
                    return legal.moves[i];
                }
            }
        }
    }

    return MOVE_NONE;
}
