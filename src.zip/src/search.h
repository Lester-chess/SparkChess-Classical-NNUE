#ifndef SEARCH_H
#define SEARCH_H

#include "types.h"
#include "board.h"
#include <chrono>
#include <atomic>
#include <vector>
#include <thread>

constexpr int MAX_PLY = 64;

struct SearchLimits {
    int depth = 64;
    uint64_t nodes = 0;
    int movetime = 0;
    int time[2] = {0, 0};
    int inc[2] = {0, 0};
    int movestogo = 0;
    bool infinite = false;
};

struct SearchThread {
    int id = 0;
    Board board;
    uint64_t nodes = 0;
    int seldepth = 0;

    Move killer_moves[MAX_PLY][2];
    int history_table[COLOR_NB][SQUARE_NB][SQUARE_NB];
    Move counter_moves[SQUARE_NB][SQUARE_NB];

    Move pv_table[MAX_PLY][MAX_PLY];
    int pv_length[MAX_PLY];

    void clear();
};

class SearchEngine {
public:
    SearchEngine();
    ~SearchEngine();

    void set_threads(int num);
    int get_threads() const { return num_threads; }

    void start_search(Board& board, const SearchLimits& limits);
    void stop();
    bool is_searching() const { return searching; }

    void wait_until_finished();

    // Benchmarking
    uint64_t bench(int depth = 7);

private:
    void thread_search(int thread_id);
    int iterative_deepening(SearchThread& st);
    int search(SearchThread& st, int depth, int alpha, int beta, int ply, bool cut_node);
    int qsearch(SearchThread& st, int alpha, int beta, int ply);

    void order_moves(SearchThread& st, MoveList& list, Move hash_move, int ply);
    void score_moves(SearchThread& st, MoveList& list, Move hash_move, int ply);

    bool check_time();

    int num_threads = 1;
    std::vector<std::thread> worker_threads;
    std::vector<SearchThread> thread_states;

    SearchLimits current_limits;
    std::chrono::high_resolution_clock::time_point start_time;
    int allocated_time_ms = 0;

    std::atomic<bool> searching{false};
    std::atomic<bool> stop_flag{false};

    Board root_board;
};

extern SearchEngine SEARCHER;

void init_search();

#endif // SEARCH_H
