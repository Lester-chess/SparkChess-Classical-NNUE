#ifndef BOOK_H
#define BOOK_H

#include "types.h"
#include "board.h"
#include <string>

// Polyglot hash keys initialization and book probing
void init_polyglot();
Move probe_book(const Board& board, const std::string& book_path, bool use_internal_fallback = true);

#endif // BOOK_H
