#include "bitboard.h"
#include "magics.h"
#include <cstring>
#include <vector>

Bitboard PAWN_ATTACKS[COLOR_NB][SQUARE_NB];
Bitboard KNIGHT_ATTACKS[SQUARE_NB];
Bitboard KING_ATTACKS[SQUARE_NB];
Bitboard BISHOP_MASKS[SQUARE_NB];
Bitboard ROOK_MASKS[SQUARE_NB];

static constexpr int BISHOP_BITS[64] = {
    6, 5, 5, 5, 5, 5, 5, 6,
    5, 5, 5, 5, 5, 5, 5, 5,
    5, 5, 7, 7, 7, 7, 5, 5,
    5, 5, 7, 9, 9, 7, 5, 5,
    5, 5, 7, 9, 9, 7, 5, 5,
    5, 5, 7, 7, 7, 7, 5, 5,
    5, 5, 5, 5, 5, 5, 5, 5,
    6, 5, 5, 5, 5, 5, 5, 6
};

static constexpr int ROOK_BITS[64] = {
    12, 11, 11, 11, 11, 11, 11, 12,
    11, 10, 10, 10, 10, 10, 10, 11,
    11, 10, 10, 10, 10, 10, 10, 11,
    11, 10, 10, 10, 10, 10, 10, 11,
    11, 10, 10, 10, 10, 10, 10, 11,
    11, 10, 10, 10, 10, 10, 10, 11,
    11, 10, 10, 10, 10, 10, 10, 11,
    12, 11, 11, 11, 11, 11, 11, 12
};

static Bitboard BISHOP_TABLE[5248];
static Bitboard ROOK_TABLE[102400];
static int BISHOP_OFFSETS[64];
static int ROOK_OFFSETS[64];

static Bitboard calc_mask_bishop(int sq) {
    Bitboard attacks = 0;
    int tr = sq / 8, tf = sq % 8;
    for (int dr : {1, -1}) {
        for (int df : {1, -1}) {
            int r = tr + dr, f = tf + df;
            while (r >= 1 && r <= 6 && f >= 1 && f <= 6) {
                attacks |= (1ULL << (r * 8 + f));
                r += dr; f += df;
            }
        }
    }
    return attacks;
}

static Bitboard calc_mask_rook(int sq) {
    Bitboard attacks = 0;
    int tr = sq / 8, tf = sq % 8;
    for (int r = tr + 1; r <= 6; ++r) attacks |= (1ULL << (r * 8 + tf));
    for (int r = tr - 1; r >= 1; --r) attacks |= (1ULL << (r * 8 + tf));
    for (int f = tf + 1; f <= 6; ++f) attacks |= (1ULL << (tr * 8 + f));
    for (int f = tf - 1; f >= 1; --f) attacks |= (1ULL << (tr * 8 + f));
    return attacks;
}

static Bitboard calc_bishop_attacks(int sq, Bitboard block) {
    Bitboard attacks = 0;
    int tr = sq / 8, tf = sq % 8;
    for (int dr : {1, -1}) {
        for (int df : {1, -1}) {
            int r = tr + dr, f = tf + df;
            while (r >= 0 && r <= 7 && f >= 0 && f <= 7) {
                attacks |= (1ULL << (r * 8 + f));
                if (block & (1ULL << (r * 8 + f))) break;
                r += dr; f += df;
            }
        }
    }
    return attacks;
}

static Bitboard calc_rook_attacks(int sq, Bitboard block) {
    Bitboard attacks = 0;
    int tr = sq / 8, tf = sq % 8;
    for (int r = tr + 1; r <= 7; ++r) {
        attacks |= (1ULL << (r * 8 + tf));
        if (block & (1ULL << (r * 8 + tf))) break;
    }
    for (int r = tr - 1; r >= 0; --r) {
        attacks |= (1ULL << (r * 8 + tf));
        if (block & (1ULL << (r * 8 + tf))) break;
    }
    for (int f = tf + 1; f <= 7; ++f) {
        attacks |= (1ULL << (tr * 8 + f));
        if (block & (1ULL << (tr * 8 + f))) break;
    }
    for (int f = tf - 1; f >= 0; --f) {
        attacks |= (1ULL << (tr * 8 + f));
        if (block & (1ULL << (tr * 8 + f))) break;
    }
    return attacks;
}

static Bitboard set_occupancy_bits(int index, int bits_in_mask, Bitboard attack_mask) {
    Bitboard occupancy = 0;
    for (int i = 0; i < bits_in_mask; ++i) {
        int sq = lsb(attack_mask);
        attack_mask &= attack_mask - 1;
        if (index & (1 << i)) occupancy |= (1ULL << sq);
    }
    return occupancy;
}

Bitboard bishop_attacks(Square sq, Bitboard occ) {
    unsigned idx = static_cast<unsigned>(((occ & BISHOP_MASKS[sq]) * BISHOP_MAGICS[sq]) >> (64 - BISHOP_BITS[sq]));
    return BISHOP_TABLE[BISHOP_OFFSETS[sq] + idx];
}

Bitboard rook_attacks(Square sq, Bitboard occ) {
    unsigned idx = static_cast<unsigned>(((occ & ROOK_MASKS[sq]) * ROOK_MAGICS[sq]) >> (64 - ROOK_BITS[sq]));
    return ROOK_TABLE[ROOK_OFFSETS[sq] + idx];
}

void init_bitboards() {
    static bool initialized = false;
    if (initialized) return;
    initialized = true;

    // Pawn attacks
    for (int sq = 0; sq < 64; ++sq) {
        Bitboard b = 1ULL << sq;
        PAWN_ATTACKS[WHITE][sq] = ((b << 7) & ~FILE_H) | ((b << 9) & ~FILE_A);
        PAWN_ATTACKS[BLACK][sq] = ((b >> 7) & ~FILE_A) | ((b >> 9) & ~FILE_H);
    }

    // Knight attacks
    int knight_offsets[8][2] = {
        {1, 2}, {1, -2}, {-1, 2}, {-1, -2},
        {2, 1}, {2, -1}, {-2, 1}, {-2, -1}
    };
    for (int sq = 0; sq < 64; ++sq) {
        KNIGHT_ATTACKS[sq] = 0;
        int r = rank_of(static_cast<Square>(sq));
        int f = file_of(static_cast<Square>(sq));
        for (auto& off : knight_offsets) {
            int nr = r + off[0];
            int nf = f + off[1];
            if (nr >= 0 && nr < 8 && nf >= 0 && nf < 8) {
                KNIGHT_ATTACKS[sq] |= (1ULL << make_square(nf, nr));
            }
        }
    }

    // King attacks
    int king_offsets[8][2] = {
        {1, 0}, {-1, 0}, {0, 1}, {0, -1},
        {1, 1}, {1, -1}, {-1, 1}, {-1, -1}
    };
    for (int sq = 0; sq < 64; ++sq) {
        KING_ATTACKS[sq] = 0;
        int r = rank_of(static_cast<Square>(sq));
        int f = file_of(static_cast<Square>(sq));
        for (auto& off : king_offsets) {
            int nr = r + off[0];
            int nf = f + off[1];
            if (nr >= 0 && nr < 8 && nf >= 0 && nf < 8) {
                KING_ATTACKS[sq] |= (1ULL << make_square(nf, nr));
            }
        }
    }

    // Bishop magic tables
    int b_offset = 0;
    for (int sq = 0; sq < 64; ++sq) {
        BISHOP_OFFSETS[sq] = b_offset;
        BISHOP_MASKS[sq] = calc_mask_bishop(sq);
        int num_indices = 1 << BISHOP_BITS[sq];
        for (int i = 0; i < num_indices; ++i) {
            Bitboard occ = set_occupancy_bits(i, BISHOP_BITS[sq], BISHOP_MASKS[sq]);
            unsigned idx = static_cast<unsigned>(((occ * BISHOP_MAGICS[sq]) >> (64 - BISHOP_BITS[sq])));
            BISHOP_TABLE[b_offset + idx] = calc_bishop_attacks(sq, occ);
        }
        b_offset += num_indices;
    }

    // Rook magic tables
    int r_offset = 0;
    for (int sq = 0; sq < 64; ++sq) {
        ROOK_OFFSETS[sq] = r_offset;
        ROOK_MASKS[sq] = calc_mask_rook(sq);
        int num_indices = 1 << ROOK_BITS[sq];
        for (int i = 0; i < num_indices; ++i) {
            Bitboard occ = set_occupancy_bits(i, ROOK_BITS[sq], ROOK_MASKS[sq]);
            unsigned idx = static_cast<unsigned>(((occ * ROOK_MAGICS[sq]) >> (64 - ROOK_BITS[sq])));
            ROOK_TABLE[r_offset + idx] = calc_rook_attacks(sq, occ);
        }
        r_offset += num_indices;
    }
}
