#include "evaluate.h"
#include "nnue.h"
#include <algorithm>

EvalMode CURRENT_EVAL_MODE = EVAL_NNUE;

void set_eval_mode(EvalMode mode) {
    CURRENT_EVAL_MODE = mode;
}

EvalMode get_eval_mode() {
    return CURRENT_EVAL_MODE;
}

// Material values (Midgame, Endgame)
static const int MATERIAL_MG[6] = { 82, 337, 365, 477, 1025, 0 };
static const int MATERIAL_EG[6] = { 94, 281, 297, 512,  936, 0 };

// PeSTO Piece-Square Tables (oriented from White's perspective, rank 1 to rank 8)
static const int PST_PAWN_MG[64] = {
      0,   0,   0,   0,   0,   0,   0,   0,
    -35,  -1, -20, -23, -15,  24,  38, -22,
    -26,  -4,  -4, -10,   3,   3,  33, -12,
    -27,  -2,  -5,  12,  17,   6,  10, -25,
    -14,  13,   6,  21,  23,  12,  17, -23,
     -6,   7,  26,  31,  65,  56,  25, -20,
     98, 134,  61,  95,  68, 126,  34, -11,
      0,   0,   0,   0,   0,   0,   0,   0
};

static const int PST_PAWN_EG[64] = {
      0,   0,   0,   0,   0,   0,   0,   0,
     13,   8,   8, -10,  -7,  -9,  -9, -11,
      4,   7,  -6,   1,   0,  -5,  -1,  -8,
     13,   9,  -3,  -7,  -7,  -8,   3,  -1,
     32,  24,  13,   5,  -2,   4,  17,  17,
     94, 100,  85,  67,  56,  53,  82,  84,
    178, 173, 158, 134, 147, 132, 165, 187,
      0,   0,   0,   0,   0,   0,   0,   0
};

static const int PST_KNIGHT_MG[64] = {
   -105, -21, -58, -33, -17, -28, -19,  -23,
    -29, -53, -12,  -3,  -1,  18, -14,  -19,
    -23,  -9,  12,  10,  19,  17,  25,  -16,
    -13,   4,  16,  13,  28,  19,  21,   -8,
     -9,  17,  19,  53,  37,  69,  18,   22,
    -47,  60,  37,  65,  84, 129,  73,   44,
    -73, -41,  72,  36,  23,  62,   7,  -17,
   -167, -89, -34, -49,  61, -97, -15, -107
};

static const int PST_KNIGHT_EG[64] = {
    -29, -51, -23, -15, -22, -18, -50,  -64,
    -42, -20, -10,  -5,  -2, -20, -23,  -44,
    -23,  -3,  -1,  15,  10,  -3, -20,  -22,
    -18,  -6,  16,  25,  16,  17,   4,  -18,
    -17,   3,  22,  22,  22,  11,   8,  -18,
    -24, -20,  10,   9,  -1,  -9, -19,  -41,
    -25,  -8, -25,  -2,  -9, -25, -24,  -52,
    -58, -38, -13, -28, -31, -27, -63,  -99
};

static const int PST_BISHOP_MG[64] = {
   -33,  -3, -14, -21, -13, -12, -39, -21,
     4,  15,  16,   0,   7,  21,  33,   1,
     0,  15,  15,  15,  14,  27,  18,  10,
    -6,  13,  13,  26,  34,  12,  10,   4,
    -4,   5,  19,  50,  37,  37,   7,  -2,
   -16,  37,  43,  40,  35,  50,  37,  -2,
   -26,  16, -18, -13,  30,  59,  18, -47,
   -29,   4, -82, -37, -25, -42,   7,  -8
};

static const int PST_BISHOP_EG[64] = {
   -23,  -9, -23,  -5,  -9, -16,  -5, -17,
   -14, -18,  -7,  -1,   4,  -9, -15, -27,
   -12,  -3,   8,  10,  13,   3,  -7, -15,
    -6,   3,  13,  19,   7,  10,  -3,  -9,
    -3,   9,  12,   9,  14,  10,   3,   2,
     2,  -8,   0,  -1,  -2,   6,   0,   4,
    -8,  -4,   7, -12,  -3, -13,  -4, -14,
   -14, -21, -11,  -8,  -7,  -9, -17, -24
};

static const int PST_ROOK_MG[64] = {
   -19, -13,   1,  17,  16,   7, -37, -26,
   -44, -16, -20,  -9,  -1,  11,  -6, -71,
   -45, -25, -16, -17,   3,   0,  -5, -33,
   -36, -26, -12,  -1,   9,  -7,   6, -23,
   -24, -11,   7,  26,  24,  35,  -8, -20,
    -5,  19,  26,  36,  17,  45,  61,  16,
    27,  32,  58,  62,  80,  67,  26,  44,
    32,  42,  32,  51,  63,   9,  31,  43
};

static const int PST_ROOK_EG[64] = {
    -9,   2,   3,  -1,  -5, -13,   4, -20,
    -6,  -6,   0,   2,  -9,  -9, -11,  -3,
    -4,   0,  -5,  -1,  -7, -12,  -8, -16,
     3,   5,   8,   4,  -5,  -6,  -8, -11,
     4,   3,  13,   1,   2,   1,  -1,   2,
     7,   7,   7,   5,   4,  -3,  -5,  -3,
    11,  13,  13,  11,  -3,   3,   8,   3,
    13,  10,  18,  15,  12,  12,   8,   5
};

static const int PST_QUEEN_MG[64] = {
    -1, -18,  -9,  10, -15, -25, -48, -18,
   -35,  -8,  11,   2,   8,  15,  -3,   1,
   -14,   2, -11,  -2,  -5,   2,  14,   5,
    -9, -26,  -9, -10,  -2,  -4,   3,  -3,
   -27, -27, -16, -16,  -1,  17,  -2,   1,
   -13, -17,   7,   8,  29,  56,  47,  57,
   -24, -39,  -5,   1, -16,  57,  28,  54,
   -28,   0,  29,  12,  59,  44,  43,  45
};

static const int PST_QUEEN_EG[64] = {
   -33, -28, -22, -43,  -5, -32, -20, -41,
   -22, -23, -30, -16, -16, -23, -36, -32,
   -16, -27,  15,   6,   9,  17,  10,   5,
   -18,  28,  19,  47,  31,  34,  39,  18,
     3,  22,  24,  45,  57,  40,  57,  36,
   -20,   6,   9,  49,  47,  35,  19,   9,
   -17,  20,  32,  41,  58,  25,  30,   0,
    -9,  22,  22,  27,  27,  19,  10,  20
};

static const int PST_KING_MG[64] = {
   -15,  36,  12, -54,   8, -28,  24,  14,
     1,   7,  -8, -64, -43, -16,   9,   8,
   -14, -14, -22, -46, -44, -30, -15, -27,
   -49,  -1, -27, -39, -46, -44, -33, -51,
   -17, -20, -12, -27, -30, -25, -14, -36,
    -9,  24,   2, -16, -20,   6,  22, -22,
    29,  -1, -20,  -7,  -8,  -4, -38, -29,
   -65,  23,  16, -15, -56, -34,   2,  13
};

static const int PST_KING_EG[64] = {
   -53, -34, -21, -11, -28, -14, -24, -43,
   -27, -11,   4,  13,  14,   4,  -5, -17,
   -19,  -3,  11,  21,  23,  16,   7,  -9,
   -18,  -4,  21,  24,  27,  23,   9, -11,
    -8,  22,  24,  27,  26,  33,  26,   3,
    10,  17,  23,  15,  20,  45,  44,  13,
   -12,  17,  14,  17,  17,  38,  23,  11,
   -74, -35, -18, -18, -11,  15,   4, -17
};

int evaluate_classical(const Board& board) {
    int mg_score[2] = {0, 0};
    int eg_score[2] = {0, 0};
    int game_phase = 0;

    for (int c = 0; c < 2; ++c) {
        Color color = static_cast<Color>(c);

        // Pawns
        Bitboard pawns = board.pieces(color, PAWN);
        while (pawns) {
            Square sq = pop_lsb(pawns);
            Square psq = (color == WHITE) ? sq : flip_square(sq);
            mg_score[c] += MATERIAL_MG[PAWN] + PST_PAWN_MG[psq];
            eg_score[c] += MATERIAL_EG[PAWN] + PST_PAWN_EG[psq];
        }

        // Knights
        Bitboard knights = board.pieces(color, KNIGHT);
        while (knights) {
            Square sq = pop_lsb(knights);
            Square psq = (color == WHITE) ? sq : flip_square(sq);
            mg_score[c] += MATERIAL_MG[KNIGHT] + PST_KNIGHT_MG[psq];
            eg_score[c] += MATERIAL_EG[KNIGHT] + PST_KNIGHT_EG[psq];
            game_phase += 1;
        }

        // Bishops
        Bitboard bishops = board.pieces(color, BISHOP);
        int bishop_count = popcount(bishops);
        if (bishop_count >= 2) {
            mg_score[c] += 30; // Bishop pair bonus
            eg_score[c] += 50;
        }
        while (bishops) {
            Square sq = pop_lsb(bishops);
            Square psq = (color == WHITE) ? sq : flip_square(sq);
            mg_score[c] += MATERIAL_MG[BISHOP] + PST_BISHOP_MG[psq];
            eg_score[c] += MATERIAL_EG[BISHOP] + PST_BISHOP_EG[psq];
            game_phase += 1;
        }

        // Rooks
        Bitboard rooks = board.pieces(color, ROOK);
        Bitboard friendly_pawns = board.pieces(color, PAWN);
        Bitboard enemy_pawns = board.pieces(~color, PAWN);
        while (rooks) {
            Square sq = pop_lsb(rooks);
            Square psq = (color == WHITE) ? sq : flip_square(sq);
            mg_score[c] += MATERIAL_MG[ROOK] + PST_ROOK_MG[psq];
            eg_score[c] += MATERIAL_EG[ROOK] + PST_ROOK_EG[psq];
            game_phase += 2;

            // Open/semi-open file bonus
            int f = file_of(sq);
            Bitboard file_mask = FILE_A << f;
            if (!(friendly_pawns & file_mask)) {
                if (!(enemy_pawns & file_mask)) {
                    mg_score[c] += 25; // Fully open file
                    eg_score[c] += 15;
                } else {
                    mg_score[c] += 15; // Semi-open file
                    eg_score[c] += 10;
                }
            }
        }

        // Queens
        Bitboard queens = board.pieces(color, QUEEN);
        while (queens) {
            Square sq = pop_lsb(queens);
            Square psq = (color == WHITE) ? sq : flip_square(sq);
            mg_score[c] += MATERIAL_MG[QUEEN] + PST_QUEEN_MG[psq];
            eg_score[c] += MATERIAL_EG[QUEEN] + PST_QUEEN_EG[psq];
            game_phase += 4;
        }

        // King
        Square ksq = board.king_square(color);
        Square p_ksq = (color == WHITE) ? ksq : flip_square(ksq);
        mg_score[c] += PST_KING_MG[p_ksq];
        eg_score[c] += PST_KING_EG[p_ksq];
    }

    // Tapered evaluation interpolation
    int mg_eval = mg_score[WHITE] - mg_score[BLACK];
    int eg_eval = eg_score[WHITE] - eg_score[BLACK];

    // Total non-pawn phase points = 24
    int phase = std::clamp(game_phase, 0, 24);
    int eval = (mg_eval * phase + eg_eval * (24 - phase)) / 24;

    // Tempo bonus (+15 centipawns for side to move)
    int tempo = 15;
    eval += (board.turn() == WHITE) ? tempo : -tempo;

    return (board.turn() == WHITE) ? eval : -eval;
}

int evaluate(const Board& board) {
    if (CURRENT_EVAL_MODE == EVAL_CLASSICAL) {
        return evaluate_classical(board);
    }
    if (CURRENT_EVAL_MODE == EVAL_NNUE) {
        return evaluate_nnue(board);
    }
    // Hybrid: blend 50% classical and 50% NNUE
    return (evaluate_classical(board) + evaluate_nnue(board)) / 2;
}
