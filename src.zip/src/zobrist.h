#ifndef ZOBRIST_H
#define ZOBRIST_H

#include "types.h"
#include <cstdint>

extern Key PIECE_KEYS[PIECE_NB][SQUARE_NB];
extern Key CASTLING_KEYS[16];
extern Key EN_PASSANT_KEYS[8];
extern Key SIDE_KEY;

void init_zobrist();

#endif // ZOBRIST_H
