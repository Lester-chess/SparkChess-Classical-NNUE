#include "search.h"
#include "evaluate.h"
#include "tt.h"
#include "movegen.h"
#include <iostream>
#include <cmath>
#include <algorithm>
#include <sstream>

SearchEngine SEARCHER;

static int LMR_TABLE[64][64];

static const int MVV_LVA[6][6] = {
    // Victim: P, N, B, R, Q, K
    // Attacker: P, N, B, R, Q, K
    { 15, 14, 13, 12, 11, 10 }, // Pawn
    { 25, 24, 23, 22, 21, 20 }, // Knight
    { 35, 34, 33, 32, 31, 30 }, // Bishop
    { 45, 44, 43, 42, 41, 40 }, // Rook
    { 55, 54, 53, 52, 51, 50 }, // Queen
    { 0,  0,  0,  0,  0,  0  }  // King
};

void init_search() {
    static bool initialized = false;
    if (initialized) return;
    initialized = true;

    for (int d = 1; d < 64; ++d) {
        for (int m = 1; m < 64; ++m) {
            LMR_TABLE[d][m] = static_cast<int>(0.75 + std::log(d) * std::log(m) / 2.25);
        }
    }
}

void SearchThread::clear() {
    nodes = 0;
    seldepth = 0;
    for (int p = 0; p < MAX_PLY; ++p) {
        killer_moves[p][0] = MOVE_NONE;
        killer_moves[p][1] = MOVE_NONE;
        pv_length[p] = 0;
    }
    for (int c = 0; c < COLOR_NB; ++c) {
        for (int from = 0; from < SQUARE_NB; ++from) {
            for (int to = 0; to < SQUARE_NB; ++to) {
                history_table[c][from][to] = 0;
            }
        }
    }
    for (int from = 0; from < SQUARE_NB; ++from) {
        for (int to = 0; to < SQUARE_NB; ++to) {
            counter_moves[from][to] = MOVE_NONE;
        }
    }
}

SearchEngine::SearchEngine() {
    init_search();
    set_threads(1);
}

SearchEngine::~SearchEngine() {
    stop();
    wait_until_finished();
}

void SearchEngine::set_threads(int num) {
    stop();
    wait_until_finished();
    num_threads = std::clamp(num, 1, 64);
    thread_states.resize(num_threads);
    for (int i = 0; i < num_threads; ++i) {
        thread_states[i].id = i;
    }
}

void SearchEngine::stop() {
    stop_flag = true;
}

void SearchEngine::wait_until_finished() {
    for (auto& t : worker_threads) {
        if (t.joinable()) t.join();
    }
    worker_threads.clear();
    searching = false;
}

bool SearchEngine::check_time() {
    if (stop_flag) return true;
    if (current_limits.infinite) return false;

    if (allocated_time_ms > 0) {
        auto now = std::chrono::high_resolution_clock::now();
        int elapsed = static_cast<int>(std::chrono::duration<double, std::milli>(now - start_time).count());
        if (elapsed >= allocated_time_ms) {
            stop_flag = true;
            return true;
        }
    }
    return false;
}

void SearchEngine::start_search(Board& board, const SearchLimits& limits) {
    stop();
    wait_until_finished();

    root_board = board;
    current_limits = limits;
    stop_flag = false;
    searching = true;
    start_time = std::chrono::high_resolution_clock::now();

    // Time management calculation
    allocated_time_ms = 0;
    if (limits.movetime > 0) {
        allocated_time_ms = limits.movetime;
    } else {
        Color us = board.turn();
        int time_left = limits.time[us];
        int inc = limits.inc[us];
        if (time_left > 0) {
            int moves_to_go = (limits.movestogo > 0) ? limits.movestogo : 30;
            allocated_time_ms = (time_left / moves_to_go) + static_cast<int>(inc * 0.75);
            // Cap to not exceed remaining time
            allocated_time_ms = std::min(allocated_time_ms, time_left - 50);
            if (allocated_time_ms < 10) allocated_time_ms = 10;
        }
    }

    TT.new_search();

    for (int i = 0; i < num_threads; ++i) {
        thread_states[i].clear();
        thread_states[i].board = board;
    }

    // Launch worker threads
    for (int i = 1; i < num_threads; ++i) {
        worker_threads.emplace_back(&SearchEngine::thread_search, this, i);
    }

    // Main thread searches
    thread_search(0);

    wait_until_finished();
}

void SearchEngine::thread_search(int thread_id) {
    SearchThread& st = thread_states[thread_id];
    iterative_deepening(st);
}

void SearchEngine::score_moves(SearchThread& st, MoveList& list, Move hash_move, int ply) {
    Color us = st.board.turn();

    for (int i = 0; i < list.size; ++i) {
        Move m = list.moves[i];

        if (m == hash_move) {
            list.scores[i] = 1000000;
        } else if (m.is_promotion()) {
            list.scores[i] = 900000 + m.promotion_type() * 1000;
        } else if (st.board.piece_at(m.to()) != NO_PIECE || m.is_en_passant()) {
            Piece victim = st.board.piece_at(m.to());
            PieceType victim_pt = (victim != NO_PIECE) ? type_of(victim) : PAWN;
            PieceType attacker_pt = type_of(st.board.piece_at(m.from()));

            int see = st.board.see(m);
            if (see >= 0) {
                list.scores[i] = 500000 + MVV_LVA[victim_pt][attacker_pt] * 1000 + see;
            } else {
                list.scores[i] = 100000 + see;
            }
        } else if (m == st.killer_moves[ply][0]) {
            list.scores[i] = 400000;
        } else if (m == st.killer_moves[ply][1]) {
            list.scores[i] = 300000;
        } else {
            // History heuristic
            int hist = st.history_table[us][m.from()][m.to()];
            list.scores[i] = std::clamp(hist, 0, 200000);
        }
    }
}

void SearchEngine::order_moves(SearchThread& st, MoveList& list, Move hash_move, int ply) {
    score_moves(st, list, hash_move, ply);
}

int SearchEngine::qsearch(SearchThread& st, int alpha, int beta, int ply) {
    if ((st.nodes & 2047) == 0 && check_time()) {
        return 0;
    }

    st.nodes++;
    if (ply > st.seldepth) st.seldepth = ply;
    if (ply >= MAX_PLY - 1) return evaluate(st.board);

    bool in_check = st.board.is_in_check();
    int stand_pat = 0;

    if (!in_check) {
        stand_pat = evaluate(st.board);
        if (stand_pat >= beta) return beta;
        if (stand_pat > alpha) alpha = stand_pat;
    }

    MoveList list;
    if (in_check) {
        generate_moves(st.board, list, GEN_ALL);
    } else {
        generate_moves(st.board, list, GEN_CAPTURES);
    }

    score_moves(st, list, MOVE_NONE, ply);

    int moves_evaluated = 0;

    for (int i = 0; i < list.size; ++i) {
        // Selection sort: pick best move
        int best_idx = i;
        for (int j = i + 1; j < list.size; ++j) {
            if (list.scores[j] > list.scores[best_idx]) best_idx = j;
        }
        std::swap(list.moves[i], list.moves[best_idx]);
        std::swap(list.scores[i], list.scores[best_idx]);

        Move m = list.moves[i];

        if (!in_check) {
            // Delta pruning
            if (!m.is_promotion() && stand_pat + 900 < alpha) continue;
            // SEE pruning: prune losing captures
            if (st.board.see(m) < 0) continue;
        }

        if (!st.board.make_move(m)) continue;
        moves_evaluated++;

        int score = -qsearch(st, -beta, -alpha, ply + 1);
        st.board.unmake_move(m);

        if (stop_flag) return 0;
        if (score >= beta) return beta;
        if (score > alpha) alpha = score;
    }

    if (in_check && moves_evaluated == 0) {
        return -VALUE_MATE + ply;
    }

    return alpha;
}

int SearchEngine::search(SearchThread& st, int depth, int alpha, int beta, int ply, bool cut_node) {
    if ((st.nodes & 2047) == 0 && check_time()) {
        return 0;
    }

    st.nodes++;
    st.pv_length[ply] = ply;

    if (ply >= MAX_PLY - 1) return evaluate(st.board);

    // Repetition and 50-move rule
    if (ply > 0 && st.board.is_draw()) {
        return VALUE_DRAW;
    }

    bool is_pv = (beta - alpha > 1);
    bool in_check = st.board.is_in_check();

    // Check extension
    if (in_check) depth++;

    if (depth <= 0) {
        return qsearch(st, alpha, beta, ply);
    }

    // Transposition Table Probe
    Move tt_move = MOVE_NONE;
    int tt_score = 0;
    if (TT.probe(st.board.get_hash(), depth, alpha, beta, ply, tt_score, tt_move)) {
        if (!is_pv) return tt_score;
    }

    int static_eval = evaluate(st.board);

    // Reverse Futility Pruning (Static Null Move Pruning)
    if (!is_pv && !in_check && depth <= 3 && static_eval - 120 * depth >= beta) {
        return static_eval;
    }

    // Null Move Pruning
    if (!is_pv && !in_check && depth >= 3 && static_eval >= beta && st.board.has_non_pawn_material(st.board.turn())) {
        st.board.make_null_move();
        int r = 2 + depth / 6;
        int null_score = -search(st, depth - 1 - r, -beta, -beta + 1, ply + 1, !cut_node);
        st.board.unmake_null_move();

        if (stop_flag) return 0;
        if (null_score >= beta) return beta;
    }

    // Move Generation and Ordering
    MoveList list;
    generate_moves(st.board, list, GEN_ALL);
    order_moves(st, list, tt_move, ply);

    Move best_move = MOVE_NONE;
    int best_score = -VALUE_INFINITE;
    int legal_moves = 0;
    TTFlag tt_flag = TT_UPPERBOUND;

    for (int i = 0; i < list.size; ++i) {
        // Selection sort
        int best_idx = i;
        for (int j = i + 1; j < list.size; ++j) {
            if (list.scores[j] > list.scores[best_idx]) best_idx = j;
        }
        std::swap(list.moves[i], list.moves[best_idx]);
        std::swap(list.scores[i], list.scores[best_idx]);

        Move m = list.moves[i];

        if (!st.board.make_move(m)) continue;
        legal_moves++;

        int score = 0;

        // Late Move Reductions (LMR)
        if (legal_moves > 4 && depth >= 3 && !in_check && !m.is_promotion() && st.board.piece_at(m.to()) == NO_PIECE) {
            int r = LMR_TABLE[std::min(depth, 63)][std::min(legal_moves, 63)];
            if (is_pv) r = std::max(0, r - 1);

            int reduced_depth = std::max(1, depth - 1 - r);
            score = -search(st, reduced_depth, -alpha - 1, -alpha, ply + 1, true);

            if (score > alpha && reduced_depth < depth - 1) {
                score = -search(st, depth - 1, -alpha - 1, -alpha, ply + 1, !cut_node);
            }
        } else if (!is_pv || legal_moves > 1) {
            // Principal Variation Search (PVS) null window
            score = -search(st, depth - 1, -alpha - 1, -alpha, ply + 1, !cut_node);
        }

        if (is_pv && (legal_moves == 1 || score > alpha)) {
            score = -search(st, depth - 1, -beta, -alpha, ply + 1, false);
        }

        st.board.unmake_move(m);

        if (stop_flag) return 0;

        if (score > best_score) {
            best_score = score;
            best_move = m;

            if (score > alpha) {
                alpha = score;
                tt_flag = TT_EXACT;

                // Update PV
                st.pv_table[ply][ply] = m;
                for (int j = ply + 1; j < st.pv_length[ply + 1]; ++j) {
                    st.pv_table[ply][j] = st.pv_table[ply + 1][j];
                }
                st.pv_length[ply] = st.pv_length[ply + 1];

                if (score >= beta) {
                    tt_flag = TT_LOWERBOUND;

                    // Update Killers and History
                    if (st.board.piece_at(m.to()) == NO_PIECE && !m.is_promotion()) {
                        if (st.killer_moves[ply][0] != m) {
                            st.killer_moves[ply][1] = st.killer_moves[ply][0];
                            st.killer_moves[ply][0] = m;
                        }
                        st.history_table[st.board.turn()][m.from()][m.to()] += depth * depth;
                    }
                    break;
                }
            }
        }
    }

    if (legal_moves == 0) {
        if (in_check) {
            return -VALUE_MATE + ply; // Checkmate
        } else {
            return VALUE_DRAW;        // Stalemate
        }
    }

    TT.store(st.board.get_hash(), depth, best_score, tt_flag, ply, best_move);
    return best_score;
}

int SearchEngine::iterative_deepening(SearchThread& st) {
    int max_d = (st.id == 0) ? current_limits.depth : current_limits.depth + (st.id % 2);
    int prev_score = 0;

    Move root_best_move = MOVE_NONE;

    for (int d = 1; d <= max_d; ++d) {
        int alpha = -static_cast<int>(VALUE_INFINITE);
        int beta = static_cast<int>(VALUE_INFINITE);

        // Aspiration Windows at depth >= 5
        if (d >= 5) {
            int delta = 25;
            alpha = std::max(-static_cast<int>(VALUE_INFINITE), prev_score - delta);
            beta = std::min(static_cast<int>(VALUE_INFINITE), prev_score + delta);

            while (!stop_flag) {
                int score = search(st, d, alpha, beta, 0, false);
                if (stop_flag) break;

                if (score <= alpha) {
                    alpha = std::max(-static_cast<int>(VALUE_INFINITE), alpha - delta);
                    delta += delta / 2;
                } else if (score >= beta) {
                    beta = std::min(static_cast<int>(VALUE_INFINITE), beta + delta);
                    delta += delta / 2;
                } else {
                    prev_score = score;
                    break;
                }
            }
        } else {
            prev_score = search(st, d, alpha, beta, 0, false);
        }

        if (stop_flag) break;

        if (st.pv_length[0] > 0) {
            root_best_move = st.pv_table[0][0];
        }

        // Print UCI info from main thread
        if (st.id == 0) {
            auto now = std::chrono::high_resolution_clock::now();
            int elapsed = static_cast<int>(std::chrono::duration<double, std::milli>(now - start_time).count());
            if (elapsed == 0) elapsed = 1;

            uint64_t total_nodes = 0;
            for (const auto& t : thread_states) total_nodes += t.nodes;
            uint64_t nps = (total_nodes * 1000) / elapsed;

            std::ostringstream ss;
            ss << "info depth " << d
               << " seldepth " << st.seldepth;

            if (std::abs(prev_score) > VALUE_MATE_IN_MAX) {
                int mate_plies = VALUE_MATE - std::abs(prev_score);
                int mate_in = (mate_plies + 1) / 2;
                if (prev_score < 0) mate_in = -mate_in;
                ss << " score mate " << mate_in;
            } else {
                ss << " score cp " << prev_score;
            }

            ss << " nodes " << total_nodes
               << " nps " << nps
               << " time " << elapsed
               << " hashfull " << TT.hashfull()
               << " pv";

            for (int i = 0; i < st.pv_length[0]; ++i) {
                ss << " " << st.pv_table[0][i].to_uci();
            }

            std::cout << ss.str() << std::endl;

            // Soft time stop: if > 60% of time used, don't start next depth
            if (allocated_time_ms > 0 && elapsed > (allocated_time_ms * 6) / 10) {
                break;
            }
        }
    }

    if (st.id == 0) {
        if (root_best_move.is_null()) {
            MoveList legal;
            generate_legal_moves(st.board, legal);
            if (legal.size > 0) root_best_move = legal.moves[0];
        }
        std::cout << "bestmove " << root_best_move.to_uci() << std::endl;
    }

    return prev_score;
}

uint64_t SearchEngine::bench(int depth) {
    std::vector<std::string> bench_fens = {
        START_FEN,
        "r3k2r/p1ppqpb1/bn2pnp1/3PN3/1p2P3/2N2Q1p/PPPBBPPP/R3K2R w KQkq - 0 1",
        "8/2p5/3p4/KP5r/1R3p1k/8/4P1P1/8 w - - 0 1",
        "r1bqkb1r/pppp1ppp/2n5/4p3/2B1n3/5N2/PPPP1PPP/RNBQK2R w KQkq - 0 4",
        "rnbqkb1r/pp2pppp/3p1n2/8/3NP3/8/PPP2PPP/RNBQKB1R w KQkq - 0 5"
    };

    uint64_t total_nodes = 0;
    auto t0 = std::chrono::high_resolution_clock::now();

    for (size_t i = 0; i < bench_fens.size(); ++i) {
        Board b(bench_fens[i]);
        SearchLimits lim;
        lim.depth = depth;
        std::cout << "Bench position " << (i + 1) << "/" << bench_fens.size() << "..." << std::endl;
        start_search(b, lim);
        for (const auto& t : thread_states) total_nodes += t.nodes;
    }

    auto t1 = std::chrono::high_resolution_clock::now();
    double ms = std::chrono::duration<double, std::milli>(t1 - t0).count();
    double nps = (total_nodes / (ms / 1000.0));

    std::cout << "========================================" << std::endl;
    std::cout << "Bench Completed: " << total_nodes << " nodes in " << ms << " ms ("
              << static_cast<uint64_t>(nps) << " NPS)" << std::endl;
    std::cout << "========================================" << std::endl;
    return total_nodes;
}
