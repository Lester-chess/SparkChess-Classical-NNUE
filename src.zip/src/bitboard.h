#ifndef BITBOARD_H
#define BITBOARD_H

#include "types.h"
#include <cstdint>

#if defined(_MSC_VER)
#include <intrin.h>
#endif

// Bit manipulation intrinsics
inline int popcount(Bitboard b) {
#if defined(_MSC_VER)
    return static_cast<int>(__popcnt64(b));
#else
    return __builtin_popcountll(b);
#endif
}

inline Square lsb(Bitboard b) {
#if defined(_MSC_VER)
    unsigned long idx;
    _BitScanForward64(&idx, b);
    return static_cast<Square>(idx);
#else
    return static_cast<Square>(__builtin_ctzll(b));
#endif
}

inline Square pop_lsb(Bitboard& b) {
    Square s = lsb(b);
    b &= b - 1;
    return s;
}

inline bool test_bit(Bitboard b, Square sq) {
    return (b & (1ULL << sq)) != 0;
}

inline void set_bit(Bitboard& b, Square sq) {
    b |= (1ULL << sq);
}

inline void clear_bit(Bitboard& b, Square sq) {
    b &= ~(1ULL << sq);
}

// Bitboard constants
constexpr Bitboard EMPTY_BB = 0ULL;
constexpr Bitboard ALL_SQUARES_BB = ~0ULL;

constexpr Bitboard FILE_A = 0x0101010101010101ULL;
constexpr Bitboard FILE_B = FILE_A << 1;
constexpr Bitboard FILE_C = FILE_A << 2;
constexpr Bitboard FILE_D = FILE_A << 3;
constexpr Bitboard FILE_E = FILE_A << 4;
constexpr Bitboard FILE_F = FILE_A << 5;
constexpr Bitboard FILE_G = FILE_A << 6;
constexpr Bitboard FILE_H = FILE_A << 7;

constexpr Bitboard RANK_1 = 0x00000000000000FFULL;
constexpr Bitboard RANK_2 = RANK_1 << 8;
constexpr Bitboard RANK_3 = RANK_1 << 16;
constexpr Bitboard RANK_4 = RANK_1 << 24;
constexpr Bitboard RANK_5 = RANK_1 << 32;
constexpr Bitboard RANK_6 = RANK_1 << 40;
constexpr Bitboard RANK_7 = RANK_1 << 48;
constexpr Bitboard RANK_8 = RANK_1 << 56;

inline Bitboard square_bb(Square sq) {
    return 1ULL << sq;
}

// Global lookup tables
extern Bitboard PAWN_ATTACKS[COLOR_NB][SQUARE_NB];
extern Bitboard KNIGHT_ATTACKS[SQUARE_NB];
extern Bitboard KING_ATTACKS[SQUARE_NB];
extern Bitboard BISHOP_MASKS[SQUARE_NB];
extern Bitboard ROOK_MASKS[SQUARE_NB];

// Attack getters
inline Bitboard pawn_attacks(Color c, Square sq) {
    return PAWN_ATTACKS[c][sq];
}

inline Bitboard knight_attacks(Square sq) {
    return KNIGHT_ATTACKS[sq];
}

inline Bitboard king_attacks(Square sq) {
    return KING_ATTACKS[sq];
}

Bitboard bishop_attacks(Square sq, Bitboard occ);
Bitboard rook_attacks(Square sq, Bitboard occ);

inline Bitboard queen_attacks(Square sq, Bitboard occ) {
    return bishop_attacks(sq, occ) | rook_attacks(sq, occ);
}

void init_bitboards();

#endif // BITBOARD_H
