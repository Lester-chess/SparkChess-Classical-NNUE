#ifndef BOARD_H
#define BOARD_H

#include "types.h"
#include "bitboard.h"
#include "zobrist.h"
#include <string>
#include <vector>

constexpr const char* START_FEN = "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1";

struct GameState {
    Square en_passant_sq = SQ_NONE;
    uint8_t castling_rights = NO_CASTLING;
    int halfmove_clock = 0;
    Piece captured_piece = NO_PIECE;
    Key hash_key = 0;
};

class Board {
public:
    Board();
    explicit Board(const std::string& fen);

    bool set_fen(const std::string& fen);
    std::string get_fen() const;
    void print() const;

    // Fast state queries
    Color turn() const { return side_to_move; }
    Key get_hash() const { return hash_key; }
    Square en_passant() const { return en_passant_sq; }
    uint8_t castling() const { return castling_rights; }
    int halfmoves() const { return halfmove_clock; }
    int fullmoves() const { return fullmove_number; }

    Piece piece_at(Square sq) const { return board_array[sq]; }
    Bitboard pieces(Color c) const { return color_bb[c]; }
    Bitboard pieces(Piece p) const { return piece_bb[p]; }
    Bitboard pieces(Color c, PieceType pt) const { return piece_bb[make_piece(c, pt)]; }
    Bitboard all_pieces() const { return color_bb[WHITE] | color_bb[BLACK]; }

    Square king_square(Color c) const {
        return lsb(piece_bb[make_piece(c, KING)]);
    }

    bool is_square_attacked(Square sq, Color attacker_color) const;
    bool is_in_check() const {
        return is_square_attacked(king_square(side_to_move), ~side_to_move);
    }
    bool is_in_check(Color c) const {
        return is_square_attacked(king_square(c), ~c);
    }

    // Move execution
    bool make_move(Move m);
    void unmake_move(Move m);
    void make_null_move();
    void unmake_null_move();

    // Legality check for pseudo-legal move
    bool is_legal(Move m) const;

    // Draw conditions
    bool is_repetition(int count = 2) const;
    bool is_fifty_move_draw() const { return halfmove_clock >= 100; }
    bool is_draw() const { return is_fifty_move_draw() || is_repetition(2); }

    // Static Exchange Evaluation
    int see(Move m) const;

    // Non-pawn material check (for null move pruning)
    bool has_non_pawn_material(Color c) const {
        Bitboard non_pawns = piece_bb[make_piece(c, KNIGHT)] |
                             piece_bb[make_piece(c, BISHOP)] |
                             piece_bb[make_piece(c, ROOK)] |
                             piece_bb[make_piece(c, QUEEN)];
        return non_pawns != 0;
    }

private:
    void clear();
    void put_piece(Piece p, Square sq);
    void remove_piece(Square sq);
    void move_piece(Square from, Square to);
    Key compute_hash() const;

    Bitboard piece_bb[PIECE_NB];
    Bitboard color_bb[COLOR_NB];
    Piece board_array[SQUARE_NB];

    Color side_to_move;
    Square en_passant_sq;
    uint8_t castling_rights;
    int halfmove_clock;
    int fullmove_number;
    Key hash_key;

    std::vector<GameState> state_history;
    std::vector<Key> repetition_history;
};

#endif // BOARD_H
