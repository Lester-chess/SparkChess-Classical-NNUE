#include "trainer.h"
#include "nnue.h"
#include "tt.h"
#include "search.h"
#include "movegen.h"
#include <fstream>
#include <iostream>
#include <sstream>
#include <random>
#include <cmath>
#include <algorithm>

NNUETrainer TRAINER;

NNUETrainer::NNUETrainer() {
    ft_weights.assign(NNUE_INPUTS * NNUE_HIDDEN, 0.0f);
    ft_biases.assign(NNUE_HIDDEN, 0.1f);
    out_weights.assign(NNUE_HIDDEN * 2, 0.0f);
    out_bias = 0.0f;

    m_ft_weights.assign(NNUE_INPUTS * NNUE_HIDDEN, 0.0f);
    v_ft_weights.assign(NNUE_INPUTS * NNUE_HIDDEN, 0.0f);

    m_ft_biases.assign(NNUE_HIDDEN, 0.0f);
    v_ft_biases.assign(NNUE_HIDDEN, 0.0f);

    m_out_weights.assign(NNUE_HIDDEN * 2, 0.0f);
    v_out_weights.assign(NNUE_HIDDEN * 2, 0.0f);

    // Initialize from GLOBAL_NNUE weights
    for (int i = 0; i < NNUE_HIDDEN; ++i) {
        ft_biases[i] = static_cast<float>(GLOBAL_NNUE.ft_biases[i]) / 128.0f;
    }
    for (size_t i = 0; i < ft_weights.size(); ++i) {
        ft_weights[i] = static_cast<float>(GLOBAL_NNUE.ft_weights[i]) / 128.0f;
    }
    out_bias = static_cast<float>(GLOBAL_NNUE.out_bias) / 400.0f;
    for (size_t i = 0; i < out_weights.size(); ++i) {
        out_weights[i] = static_cast<float>(GLOBAL_NNUE.out_weights[i]) / 128.0f;
    }
}

Move NNUETrainer::parse_san_move(Board& board, const std::string& san_raw) {
    if (san_raw.empty()) return MOVE_NONE;

    std::string clean = san_raw;
    while (!clean.empty() && (clean.back() == '+' || clean.back() == '#' || clean.back() == '!' || clean.back() == '?')) {
        clean.pop_back();
    }
    if (clean.empty()) return MOVE_NONE;

    MoveList legal;
    generate_legal_moves(board, legal);

    // 1. Direct UCI match
    for (int i = 0; i < legal.size; ++i) {
        if (legal.moves[i].to_uci() == clean) return legal.moves[i];
    }

    // 2. Castling
    if (clean == "O-O" || clean == "0-0") {
        for (int i = 0; i < legal.size; ++i) {
            Move m = legal.moves[i];
            if (m.is_castling() && (m.to() == SQ_G1 || m.to() == SQ_G8)) return m;
        }
    }
    if (clean == "O-O-O" || clean == "0-0-0") {
        for (int i = 0; i < legal.size; ++i) {
            Move m = legal.moves[i];
            if (m.is_castling() && (m.to() == SQ_C1 || m.to() == SQ_C8)) return m;
        }
    }

    // 3. Promotion
    PieceType promo_pt = NO_PIECE_TYPE;
    size_t eq_pos = clean.find('=');
    if (eq_pos != std::string::npos) {
        char pchar = clean[eq_pos + 1];
        if (pchar == 'Q') promo_pt = QUEEN;
        else if (pchar == 'R') promo_pt = ROOK;
        else if (pchar == 'B') promo_pt = BISHOP;
        else if (pchar == 'N') promo_pt = KNIGHT;
        clean = clean.substr(0, eq_pos);
    }

    // 4. Target square from end of string
    if (clean.size() < 2) return MOVE_NONE;
    int to_file = clean[clean.size() - 2] - 'a';
    int to_rank = clean[clean.size() - 1] - '1';
    if (to_file < 0 || to_file > 7 || to_rank < 0 || to_rank > 7) return MOVE_NONE;
    Square target_sq = make_square(to_file, to_rank);

    // 5. Piece type
    PieceType moving_pt = PAWN;
    char first_char = clean[0];
    if (first_char == 'N') moving_pt = KNIGHT;
    else if (first_char == 'B') moving_pt = BISHOP;
    else if (first_char == 'R') moving_pt = ROOK;
    else if (first_char == 'Q') moving_pt = QUEEN;
    else if (first_char == 'K') moving_pt = KING;

    // Disambiguation
    int disambig_file = -1;
    int disambig_rank = -1;
    std::string prefix = clean.substr((moving_pt == PAWN) ? 0 : 1, clean.size() - 2 - ((moving_pt == PAWN) ? 0 : 1));
    for (char c : prefix) {
        if (c >= 'a' && c <= 'h') disambig_file = c - 'a';
        else if (c >= '1' && c <= '8') disambig_rank = c - '1';
    }

    for (int i = 0; i < legal.size; ++i) {
        Move m = legal.moves[i];
        if (m.to() != target_sq) continue;
        if (type_of(board.piece_at(m.from())) != moving_pt) continue;
        if (promo_pt != NO_PIECE_TYPE && (!m.is_promotion() || m.promotion_type() != promo_pt)) continue;
        if (disambig_file != -1 && file_of(m.from()) != disambig_file) continue;
        if (disambig_rank != -1 && rank_of(m.from()) != disambig_rank) continue;
        return m;
    }

    return MOVE_NONE;
}

int NNUETrainer::load_pgn(const std::string& pgn_path, std::vector<TrainingSample>& dataset, int max_games) {
    std::ifstream file(pgn_path);
    if (!file.is_open()) {
        std::cerr << "Cannot open PGN file: " << pgn_path << std::endl;
        return 0;
    }

    std::string line;
    int games_parsed = 0;
    float outcome = 0.5f;
    std::vector<TrainingSample> game_samples;

    Board board;
    board.set_fen(START_FEN);

    while (std::getline(file, line)) {
        if (line.empty()) continue;

        if (line[0] == '[') {
            if (line.find("[Result ") == 0) {
                if (line.find("1-0") != std::string::npos) outcome = 1.0f;
                else if (line.find("0-1") != std::string::npos) outcome = 0.0f;
                else outcome = 0.5f;
            }
            continue;
        }

        std::istringstream ss(line);
        std::string token;
        while (ss >> token) {
            if (token == "1-0" || token == "0-1" || token == "1/2-1/2" || token == "*") {
                if (!game_samples.empty()) {
                    for (auto& s : game_samples) {
                        s.outcome = outcome;
                        dataset.push_back(s);
                    }
                    game_samples.clear();
                    games_parsed++;
                    if (games_parsed >= max_games) break;
                }
                board.set_fen(START_FEN);
                outcome = 0.5f;
                continue;
            }

            if (token.back() == '.' || std::isdigit(token[0])) {
                size_t dot_pos = token.find('.');
                if (dot_pos != std::string::npos) {
                    token = token.substr(dot_pos + 1);
                    while (!token.empty() && token[0] == '.') token = token.substr(1);
                    if (token.empty()) continue;
                }
            }

            Move m = parse_san_move(board, token);
            if (m.is_null()) continue;

            TrainingSample sample;
            sample.turn = board.turn();
            for (int sq = 0; sq < SQUARE_NB; ++sq) {
                Piece p = board.piece_at(static_cast<Square>(sq));
                if (p != NO_PIECE) {
                    sample.features_w.push_back(get_feature_index(WHITE, p, static_cast<Square>(sq)));
                    sample.features_b.push_back(get_feature_index(BLACK, p, static_cast<Square>(sq)));
                }
            }
            game_samples.push_back(sample);

            board.make_move(m);
        }

        if (games_parsed >= max_games) break;
    }

    std::cout << "Successfully parsed " << games_parsed << " games (" << dataset.size() << " positions) from " << pgn_path << std::endl;
    return games_parsed;
}

int NNUETrainer::generate_selfplay(int num_games, int depth, std::vector<TrainingSample>& dataset) {
    std::cout << "Starting self-play generation: " << num_games << " games at depth " << depth << "..." << std::endl;

    std::mt19937 rng(42);

    for (int g = 0; g < num_games; ++g) {
        Board board(START_FEN);
        std::vector<TrainingSample> game_samples;

        int plies = 0;
        float outcome = 0.5f;

        while (plies < 150) {
            if (board.is_draw()) {
                outcome = 0.5f;
                break;
            }

            MoveList legal;
            generate_legal_moves(board, legal);
            if (legal.size == 0) {
                if (board.is_in_check()) {
                    outcome = (board.turn() == WHITE) ? 0.0f : 1.0f;
                } else {
                    outcome = 0.5f;
                }
                break;
            }

            TrainingSample sample;
            sample.turn = board.turn();
            for (int sq = 0; sq < SQUARE_NB; ++sq) {
                Piece p = board.piece_at(static_cast<Square>(sq));
                if (p != NO_PIECE) {
                    sample.features_w.push_back(get_feature_index(WHITE, p, static_cast<Square>(sq)));
                    sample.features_b.push_back(get_feature_index(BLACK, p, static_cast<Square>(sq)));
                }
            }
            game_samples.push_back(sample);

            Move chosen = MOVE_NONE;
            if (plies < 2) {
                std::uniform_int_distribution<int> dist(0, legal.size - 1);
                chosen = legal.moves[dist(rng)];
            } else {
                SearchLimits lim;
                lim.depth = depth;
                SEARCHER.start_search(board, lim);

                int dummy_score;
                TT.probe(board.get_hash(), 0, -static_cast<int>(VALUE_INFINITE), static_cast<int>(VALUE_INFINITE), 0, dummy_score, chosen);
                if (chosen.is_null()) chosen = legal.moves[0];
            }

            board.make_move(chosen);
            plies++;
        }

        for (auto& s : game_samples) {
            s.outcome = outcome;
            dataset.push_back(s);
        }

        if ((g + 1) % 10 == 0 || g == num_games - 1) {
            std::cout << "Generated " << (g + 1) << "/" << num_games << " games (" << dataset.size() << " samples)..." << std::endl;
        }
    }

    return num_games;
}

void NNUETrainer::train(std::vector<TrainingSample>& dataset, int epochs, int batch_size, float lr, const std::string& output_file) {
    if (dataset.empty()) {
        std::cerr << "Cannot train on empty dataset!" << std::endl;
        return;
    }

    std::cout << "Training NNUE on " << dataset.size() << " positions (" << epochs << " epochs, batch size " << batch_size << ", lr " << lr << ")..." << std::endl;

    std::mt19937 g(12345);

    const float beta1 = 0.9f;
    const float beta2 = 0.999f;
    const float eps = 1e-8f;
    int step = 0;

    for (int ep = 1; ep <= epochs; ++ep) {
        std::shuffle(dataset.begin(), dataset.end(), g);
        float total_loss = 0.0f;
        int num_batches = (static_cast<int>(dataset.size()) + batch_size - 1) / batch_size;

        for (int b = 0; b < num_batches; ++b) {
            step++;
            int start_idx = b * batch_size;
            int end_idx = std::min(start_idx + batch_size, static_cast<int>(dataset.size()));
            int current_batch = end_idx - start_idx;

            float pow_beta1 = static_cast<float>(std::pow(beta1, step));
            float pow_beta2 = static_cast<float>(std::pow(beta2, step));
            float corr1 = 1.0f - pow_beta1;
            float corr2 = 1.0f - pow_beta2;

            for (int s = start_idx; s < end_idx; ++s) {
                const auto& sample = dataset[s];

                std::vector<float> acc_w = ft_biases;
                std::vector<float> acc_b = ft_biases;

                for (int feat : sample.features_w) {
                    const float* w = &ft_weights[feat * NNUE_HIDDEN];
                    for (int i = 0; i < NNUE_HIDDEN; ++i) acc_w[i] += w[i];
                }
                for (int feat : sample.features_b) {
                    const float* w = &ft_weights[feat * NNUE_HIDDEN];
                    for (int i = 0; i < NNUE_HIDDEN; ++i) acc_b[i] += w[i];
                }

                const std::vector<float>& acc_us = (sample.turn == WHITE) ? acc_w : acc_b;
                const std::vector<float>& acc_them = (sample.turn == WHITE) ? acc_b : acc_w;

                float h[NNUE_HIDDEN * 2];
                for (int i = 0; i < NNUE_HIDDEN; ++i) {
                    h[i] = std::clamp(acc_us[i], 0.0f, 1.0f);
                    h[NNUE_HIDDEN + i] = std::clamp(acc_them[i], 0.0f, 1.0f);
                }

                float net_out = out_bias;
                for (int i = 0; i < NNUE_HIDDEN * 2; ++i) {
                    net_out += h[i] * out_weights[i];
                }

                float pred = 1.0f / (1.0f + std::exp(-net_out));
                float target = (sample.turn == WHITE) ? sample.outcome : (1.0f - sample.outcome);

                float error = pred - target;
                total_loss += error * error;

                float grad_out = error * pred * (1.0f - pred);

                // Update out_bias with Adam
                m_out_bias = beta1 * m_out_bias + (1.0f - beta1) * grad_out;
                v_out_bias = beta2 * v_out_bias + (1.0f - beta2) * (grad_out * grad_out);
                float m_hat_b = m_out_bias / corr1;
                float v_hat_b = v_out_bias / corr2;
                out_bias -= lr * m_hat_b / (std::sqrt(v_hat_b) + eps) / current_batch;

                for (int i = 0; i < NNUE_HIDDEN * 2; ++i) {
                    float g_w = grad_out * h[i];
                    m_out_weights[i] = beta1 * m_out_weights[i] + (1.0f - beta1) * g_w;
                    v_out_weights[i] = beta2 * v_out_weights[i] + (1.0f - beta2) * (g_w * g_w);
                    float m_hat = m_out_weights[i] / corr1;
                    float v_hat = v_out_weights[i] / corr2;
                    out_weights[i] -= lr * m_hat / (std::sqrt(v_hat) + eps) / current_batch;
                }

                // Backprop to accumulator features
                for (int i = 0; i < NNUE_HIDDEN; ++i) {
                    if (acc_us[i] > 0.0f && acc_us[i] < 1.0f) {
                        float g_feat = grad_out * out_weights[i];
                        ft_biases[i] -= lr * g_feat / current_batch;

                        const auto& active_feats = (sample.turn == WHITE) ? sample.features_w : sample.features_b;
                        for (int feat : active_feats) {
                            ft_weights[feat * NNUE_HIDDEN + i] -= lr * g_feat / current_batch;
                        }
                    }

                    if (acc_them[i] > 0.0f && acc_them[i] < 1.0f) {
                        float g_feat = grad_out * out_weights[NNUE_HIDDEN + i];
                        ft_biases[i] -= lr * g_feat / current_batch;

                        const auto& active_feats = (sample.turn == WHITE) ? sample.features_b : sample.features_w;
                        for (int feat : active_feats) {
                            ft_weights[feat * NNUE_HIDDEN + i] -= lr * g_feat / current_batch;
                        }
                    }
                }
            }
        }

        std::cout << "Epoch " << ep << "/" << epochs << " - Loss: " << (total_loss / dataset.size()) << std::endl;
    }

    // Quantize into GLOBAL_NNUE
    for (int i = 0; i < NNUE_HIDDEN; ++i) {
        GLOBAL_NNUE.ft_biases[i] = static_cast<int16_t>(std::clamp(ft_biases[i] * 128.0f, -32767.0f, 32767.0f));
    }
    for (size_t i = 0; i < ft_weights.size(); ++i) {
        GLOBAL_NNUE.ft_weights[i] = static_cast<int16_t>(std::clamp(ft_weights[i] * 128.0f, -32767.0f, 32767.0f));
    }
    GLOBAL_NNUE.out_bias = static_cast<int32_t>(out_bias * 400.0f);
    for (size_t i = 0; i < out_weights.size(); ++i) {
        GLOBAL_NNUE.out_weights[i] = static_cast<int16_t>(std::clamp(out_weights[i] * 128.0f, -32767.0f, 32767.0f));
    }

    save_nnue(output_file);
    std::cout << "Trained weights quantized and saved to: " << output_file << std::endl;
}
