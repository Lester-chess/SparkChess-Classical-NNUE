#ifndef MOVEGEN_H
#define MOVEGEN_H

#include "types.h"
#include "board.h"

enum GenType {
    GEN_ALL,
    GEN_CAPTURES
};

void generate_moves(const Board& board, MoveList& list, GenType type = GEN_ALL);
void generate_legal_moves(Board& board, MoveList& list);

#endif // MOVEGEN_H
