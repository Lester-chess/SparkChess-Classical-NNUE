#include "board.h"
#include <sstream>
#include <cctype>
#include <iostream>
#include <algorithm>

static const uint8_t CASTLING_MASK[SQUARE_NB] = {
    static_cast<uint8_t>(~WHITE_OOO), 0xFF, 0xFF, 0xFF, static_cast<uint8_t>(~WHITE_ANY), 0xFF, 0xFF, static_cast<uint8_t>(~WHITE_OO),
    0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
    0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
    0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
    0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
    0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
    0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
    static_cast<uint8_t>(~BLACK_OOO), 0xFF, 0xFF, 0xFF, static_cast<uint8_t>(~BLACK_ANY), 0xFF, 0xFF, static_cast<uint8_t>(~BLACK_OO)
};

static const int SEE_VALUES[PIECE_TYPE_NB + 1] = {
    100, 320, 330, 500, 900, 20000, 0
};

Board::Board() {
    init_bitboards();
    init_zobrist();
    set_fen(START_FEN);
}

Board::Board(const std::string& fen) {
    init_bitboards();
    init_zobrist();
    set_fen(fen);
}

void Board::clear() {
    for (int i = 0; i < PIECE_NB; ++i) piece_bb[i] = 0ULL;
    for (int i = 0; i < COLOR_NB; ++i) color_bb[i] = 0ULL;
    for (int i = 0; i < SQUARE_NB; ++i) board_array[i] = NO_PIECE;

    side_to_move = WHITE;
    en_passant_sq = SQ_NONE;
    castling_rights = NO_CASTLING;
    halfmove_clock = 0;
    fullmove_number = 1;
    hash_key = 0;

    state_history.clear();
    repetition_history.clear();
}

void Board::put_piece(Piece p, Square sq) {
    Bitboard b = square_bb(sq);
    piece_bb[p] |= b;
    color_bb[color_of(p)] |= b;
    board_array[sq] = p;
    hash_key ^= PIECE_KEYS[p][sq];
}

void Board::remove_piece(Square sq) {
    Piece p = board_array[sq];
    if (p == NO_PIECE) return;
    Bitboard b = square_bb(sq);
    piece_bb[p] &= ~b;
    color_bb[color_of(p)] &= ~b;
    board_array[sq] = NO_PIECE;
    hash_key ^= PIECE_KEYS[p][sq];
}

void Board::move_piece(Square from, Square to) {
    Piece p = board_array[from];
    Bitboard from_to = square_bb(from) | square_bb(to);
    piece_bb[p] ^= from_to;
    color_bb[color_of(p)] ^= from_to;
    board_array[from] = NO_PIECE;
    board_array[to] = p;
    hash_key ^= PIECE_KEYS[p][from] ^ PIECE_KEYS[p][to];
}

Key Board::compute_hash() const {
    Key k = 0;
    for (int sq = 0; sq < SQUARE_NB; ++sq) {
        Piece p = board_array[sq];
        if (p != NO_PIECE) {
            k ^= PIECE_KEYS[p][sq];
        }
    }
    k ^= CASTLING_KEYS[castling_rights];
    if (en_passant_sq != SQ_NONE) {
        k ^= EN_PASSANT_KEYS[file_of(en_passant_sq)];
    }
    if (side_to_move == BLACK) {
        k ^= SIDE_KEY;
    }
    return k;
}

bool Board::set_fen(const std::string& fen) {
    clear();
    std::istringstream ss(fen);
    std::string piece_placement, active_color, castling, ep_square;
    int halfmove = 0, fullmove = 1;

    if (!(ss >> piece_placement >> active_color)) return false;

    int r = 7, f = 0;
    for (char c : piece_placement) {
        if (c == '/') {
            r--;
            f = 0;
        } else if (std::isdigit(c)) {
            f += c - '0';
        } else {
            Piece p = NO_PIECE;
            switch (c) {
                case 'P': p = W_PAWN; break;
                case 'N': p = W_KNIGHT; break;
                case 'B': p = W_BISHOP; break;
                case 'R': p = W_ROOK; break;
                case 'Q': p = W_QUEEN; break;
                case 'K': p = W_KING; break;
                case 'p': p = B_PAWN; break;
                case 'n': p = B_KNIGHT; break;
                case 'b': p = B_BISHOP; break;
                case 'r': p = B_ROOK; break;
                case 'q': p = B_QUEEN; break;
                case 'k': p = B_KING; break;
                default: return false;
            }
            if (f < 8 && r >= 0) {
                put_piece(p, make_square(f, r));
                f++;
            }
        }
    }

    side_to_move = (active_color == "b") ? BLACK : WHITE;

    if (ss >> castling) {
        for (char c : castling) {
            if (c == 'K') castling_rights |= WHITE_OO;
            else if (c == 'Q') castling_rights |= WHITE_OOO;
            else if (c == 'k') castling_rights |= BLACK_OO;
            else if (c == 'q') castling_rights |= BLACK_OOO;
        }
    }

    if (ss >> ep_square) {
        if (ep_square != "-" && ep_square.size() >= 2) {
            int ep_f = ep_square[0] - 'a';
            int ep_r = ep_square[1] - '1';
            if (ep_f >= 0 && ep_f < 8 && ep_r >= 0 && ep_r < 8) {
                en_passant_sq = make_square(ep_f, ep_r);
            }
        }
    }

    if (ss >> halfmove) halfmove_clock = halfmove;
    if (ss >> fullmove) fullmove_number = fullmove;

    hash_key = compute_hash();
    repetition_history.push_back(hash_key);
    return true;
}

std::string Board::get_fen() const {
    std::string fen;
    for (int r = 7; r >= 0; --r) {
        int empty = 0;
        for (int f = 0; f < 8; ++f) {
            Square sq = make_square(f, r);
            Piece p = board_array[sq];
            if (p == NO_PIECE) {
                empty++;
            } else {
                if (empty > 0) {
                    fen += std::to_string(empty);
                    empty = 0;
                }
                const char symbols[] = "PNBRQKpnbrqk";
                fen += symbols[p];
            }
        }
        if (empty > 0) fen += std::to_string(empty);
        if (r > 0) fen += '/';
    }

    fen += (side_to_move == WHITE) ? " w " : " b ";

    std::string castling;
    if (castling_rights & WHITE_OO) castling += 'K';
    if (castling_rights & WHITE_OOO) castling += 'Q';
    if (castling_rights & BLACK_OO) castling += 'k';
    if (castling_rights & BLACK_OOO) castling += 'q';
    if (castling.empty()) castling = "-";
    fen += castling + " ";

    if (en_passant_sq != SQ_NONE) {
        fen += static_cast<char>('a' + file_of(en_passant_sq));
        fen += static_cast<char>('1' + rank_of(en_passant_sq));
    } else {
        fen += "-";
    }

    fen += " " + std::to_string(halfmove_clock) + " " + std::to_string(fullmove_number);
    return fen;
}

void Board::print() const {
    std::cout << "\n  +---+---+---+---+---+---+---+---+\n";
    for (int r = 7; r >= 0; --r) {
        std::cout << (r + 1) << " |";
        for (int f = 0; f < 8; ++f) {
            Square sq = make_square(f, r);
            Piece p = board_array[sq];
            char c = '.';
            if (p != NO_PIECE) {
                const char symbols[] = "PNBRQKpnbrqk";
                c = symbols[p];
            }
            std::cout << " " << c << " |";
        }
        std::cout << "\n  +---+---+---+---+---+---+---+---+\n";
    }
    std::cout << "    a   b   c   d   e   f   g   h\n\n";
    std::cout << "FEN: " << get_fen() << "\n";
    std::cout << "Key: 0x" << std::hex << hash_key << std::dec << "\n\n";
}

bool Board::is_square_attacked(Square sq, Color attacker_color) const {
    Bitboard occ = all_pieces();

    // Attacked by pawns
    Color defender_color = ~attacker_color;
    if (pawn_attacks(defender_color, sq) & piece_bb[make_piece(attacker_color, PAWN)])
        return true;

    // Attacked by knights
    if (knight_attacks(sq) & piece_bb[make_piece(attacker_color, KNIGHT)])
        return true;

    // Attacked by kings
    if (king_attacks(sq) & piece_bb[make_piece(attacker_color, KING)])
        return true;

    // Attacked by bishops or queens
    Bitboard bishop_attackers = piece_bb[make_piece(attacker_color, BISHOP)] | piece_bb[make_piece(attacker_color, QUEEN)];
    if (bishop_attackers && (bishop_attacks(sq, occ) & bishop_attackers))
        return true;

    // Attacked by rooks or queens
    Bitboard rook_attackers = piece_bb[make_piece(attacker_color, ROOK)] | piece_bb[make_piece(attacker_color, QUEEN)];
    if (rook_attackers && (rook_attacks(sq, occ) & rook_attackers))
        return true;

    return false;
}

bool Board::make_move(Move m) {
    Square from = m.from();
    Square to = m.to();
    Piece moving_piece = board_array[from];
    Color us = side_to_move;
    Color them = ~us;

    GameState state;
    state.en_passant_sq = en_passant_sq;
    state.castling_rights = castling_rights;
    state.halfmove_clock = halfmove_clock;
    state.captured_piece = board_array[to];
    state.hash_key = hash_key;
    state_history.push_back(state);
    repetition_history.push_back(hash_key);

    // Remove old hash features
    hash_key ^= CASTLING_KEYS[castling_rights];
    if (en_passant_sq != SQ_NONE) {
        hash_key ^= EN_PASSANT_KEYS[file_of(en_passant_sq)];
    }
    hash_key ^= SIDE_KEY;

    // Reset en passant square
    en_passant_sq = SQ_NONE;

    // Reset halfmove clock if pawn move or capture
    if (type_of(moving_piece) == PAWN || state.captured_piece != NO_PIECE) {
        halfmove_clock = 0;
    } else {
        halfmove_clock++;
    }

    if (m.is_en_passant()) {
        Square cap_sq = (us == WHITE) ? static_cast<Square>(to - 8) : static_cast<Square>(to + 8);
        remove_piece(cap_sq);
        move_piece(from, to);
    } else if (m.is_castling()) {
        move_piece(from, to);
        Square r_from, r_to;
        if (to == SQ_G1) { r_from = SQ_H1; r_to = SQ_F1; }
        else if (to == SQ_C1) { r_from = SQ_A1; r_to = SQ_D1; }
        else if (to == SQ_G8) { r_from = SQ_H8; r_to = SQ_F8; }
        else { r_from = SQ_A8; r_to = SQ_D8; }
        move_piece(r_from, r_to);
    } else {
        if (state.captured_piece != NO_PIECE) {
            remove_piece(to);
        }
        if (m.is_promotion()) {
            remove_piece(from);
            put_piece(make_piece(us, m.promotion_type()), to);
        } else {
            move_piece(from, to);
            if (type_of(moving_piece) == PAWN && std::abs(rank_of(to) - rank_of(from)) == 2) {
                Square ep = (us == WHITE) ? static_cast<Square>(from + 8) : static_cast<Square>(from - 8);
                if (pawn_attacks(us, ep) & piece_bb[make_piece(them, PAWN)]) {
                    en_passant_sq = ep;
                    hash_key ^= EN_PASSANT_KEYS[file_of(en_passant_sq)];
                }
            }
        }
    }

    // Update castling rights
    castling_rights &= CASTLING_MASK[from] & CASTLING_MASK[to];
    hash_key ^= CASTLING_KEYS[castling_rights];

    if (us == BLACK) fullmove_number++;
    side_to_move = them;

    if (is_square_attacked(king_square(us), them)) {
        unmake_move(m);
        return false;
    }

    return true;
}

void Board::unmake_move(Move m) {
    if (state_history.empty()) return;

    repetition_history.pop_back();
    GameState state = state_history.back();
    state_history.pop_back();

    Color them = side_to_move;
    Color us = ~them;
    side_to_move = us;

    Square from = m.from();
    Square to = m.to();

    if (m.is_en_passant()) {
        move_piece(to, from);
        Square cap_sq = (us == WHITE) ? static_cast<Square>(to - 8) : static_cast<Square>(to + 8);
        put_piece(make_piece(them, PAWN), cap_sq);
    } else if (m.is_castling()) {
        move_piece(to, from);
        Square r_from, r_to;
        if (to == SQ_G1) { r_from = SQ_H1; r_to = SQ_F1; }
        else if (to == SQ_C1) { r_from = SQ_A1; r_to = SQ_D1; }
        else if (to == SQ_G8) { r_from = SQ_H8; r_to = SQ_F8; }
        else { r_from = SQ_A8; r_to = SQ_D8; }
        move_piece(r_to, r_from);
    } else if (m.is_promotion()) {
        remove_piece(to);
        put_piece(make_piece(us, PAWN), from);
        if (state.captured_piece != NO_PIECE) {
            put_piece(state.captured_piece, to);
        }
    } else {
        move_piece(to, from);
        if (state.captured_piece != NO_PIECE) {
            put_piece(state.captured_piece, to);
        }
    }

    en_passant_sq = state.en_passant_sq;
    castling_rights = state.castling_rights;
    halfmove_clock = state.halfmove_clock;
    hash_key = state.hash_key;

    if (us == BLACK) fullmove_number--;
}

void Board::make_null_move() {
    GameState state;
    state.en_passant_sq = en_passant_sq;
    state.castling_rights = castling_rights;
    state.halfmove_clock = halfmove_clock;
    state.captured_piece = NO_PIECE;
    state.hash_key = hash_key;
    state_history.push_back(state);
    repetition_history.push_back(hash_key);

    if (en_passant_sq != SQ_NONE) {
        hash_key ^= EN_PASSANT_KEYS[file_of(en_passant_sq)];
        en_passant_sq = SQ_NONE;
    }

    hash_key ^= SIDE_KEY;
    side_to_move = ~side_to_move;
    halfmove_clock++;
}

void Board::unmake_null_move() {
    if (state_history.empty()) return;
    repetition_history.pop_back();
    GameState state = state_history.back();
    state_history.pop_back();

    side_to_move = ~side_to_move;
    en_passant_sq = state.en_passant_sq;
    castling_rights = state.castling_rights;
    halfmove_clock = state.halfmove_clock;
    hash_key = state.hash_key;
}

bool Board::is_legal(Move m) const {
    Board copy = *this;
    return copy.make_move(m);
}

bool Board::is_repetition(int count) const {
    int reps = 0;
    int limit = std::min(halfmove_clock, static_cast<int>(repetition_history.size()) - 1);
    for (int i = 0; i <= limit; ++i) {
        int idx = static_cast<int>(repetition_history.size()) - 1 - i;
        if (idx >= 0 && repetition_history[idx] == hash_key) {
            reps++;
            if (reps >= count) return true;
        }
    }
    return false;
}

int Board::see(Move m) const {
    Square from = m.from();
    Square to = m.to();

    PieceType target_pt = (board_array[to] != NO_PIECE) ? type_of(board_array[to]) : NO_PIECE_TYPE;
    if (m.is_en_passant()) target_pt = PAWN;

    int gain[32];
    int d = 0;
    gain[d] = SEE_VALUES[target_pt];

    PieceType attacker_pt = type_of(board_array[from]);
    if (m.is_promotion()) attacker_pt = m.promotion_type();

    Bitboard from_bb = square_bb(from);
    Bitboard occ = all_pieces();

    Color side = ~side_to_move;

    do {
        d++;
        gain[d] = SEE_VALUES[attacker_pt] - gain[d - 1];
        if (std::max(-gain[d - 1], gain[d]) < 0) break;

        occ ^= from_bb;

        Bitboard pawns = pawn_attacks(~side, to) & piece_bb[make_piece(side, PAWN)] & occ;
        if (pawns) {
            attacker_pt = PAWN;
            from_bb = square_bb(lsb(pawns));
            side = ~side;
            continue;
        }
        Bitboard knights = knight_attacks(to) & piece_bb[make_piece(side, KNIGHT)] & occ;
        if (knights) {
            attacker_pt = KNIGHT;
            from_bb = square_bb(lsb(knights));
            side = ~side;
            continue;
        }
        Bitboard bishops = bishop_attacks(to, occ) & piece_bb[make_piece(side, BISHOP)] & occ;
        if (bishops) {
            attacker_pt = BISHOP;
            from_bb = square_bb(lsb(bishops));
            side = ~side;
            continue;
        }
        Bitboard rooks = rook_attacks(to, occ) & piece_bb[make_piece(side, ROOK)] & occ;
        if (rooks) {
            attacker_pt = ROOK;
            from_bb = square_bb(lsb(rooks));
            side = ~side;
            continue;
        }
        Bitboard queens = queen_attacks(to, occ) & piece_bb[make_piece(side, QUEEN)] & occ;
        if (queens) {
            attacker_pt = QUEEN;
            from_bb = square_bb(lsb(queens));
            side = ~side;
            continue;
        }
        Bitboard king = king_attacks(to) & piece_bb[make_piece(side, KING)] & occ;
        if (king) {
            attacker_pt = KING;
            from_bb = square_bb(lsb(king));
            side = ~side;
            if (is_square_attacked(to, side)) break;
            continue;
        }

        break;
    } while (d < 31);

    while (--d > 0) {
        gain[d - 1] = -std::max(-gain[d - 1], gain[d]);
    }
    return gain[0];
}
