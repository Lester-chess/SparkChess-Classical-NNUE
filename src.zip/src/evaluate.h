#ifndef EVALUATE_H
#define EVALUATE_H

#include "types.h"
#include "board.h"

enum EvalMode {
    EVAL_CLASSICAL,
    EVAL_NNUE,
    EVAL_HYBRID
};

// Global evaluation mode
extern EvalMode CURRENT_EVAL_MODE;

int evaluate(const Board& board);
int evaluate_classical(const Board& board);
int evaluate_nnue(const Board& board);

void set_eval_mode(EvalMode mode);
EvalMode get_eval_mode();

#endif // EVALUATE_H
