#ifndef TYPES_H
#define TYPES_H

#include <cstdint>
#include <string>
#include <iostream>
#include <vector>
#include <algorithm>

// Basic integer types for chess engine
using Bitboard = uint64_t;
using Key = uint64_t;

// Colors
enum Color : int {
    WHITE = 0,
    BLACK = 1,
    COLOR_NB = 2
};

constexpr Color operator~(Color c) {
    return static_cast<Color>(c ^ 1);
}

// Piece Types
enum PieceType : int {
    PAWN = 0,
    KNIGHT = 1,
    BISHOP = 2,
    ROOK = 3,
    QUEEN = 4,
    KING = 5,
    NO_PIECE_TYPE = 6,
    PIECE_TYPE_NB = 6
};

// Pieces
enum Piece : int {
    W_PAWN = 0, W_KNIGHT = 1, W_BISHOP = 2, W_ROOK = 3, W_QUEEN = 4, W_KING = 5,
    B_PAWN = 6, B_KNIGHT = 7, B_BISHOP = 8, B_ROOK = 9, B_QUEEN = 10, B_KING = 11,
    NO_PIECE = 12,
    PIECE_NB = 12
};

constexpr Piece make_piece(Color c, PieceType pt) {
    return static_cast<Piece>((c * 6) + pt);
}

constexpr PieceType type_of(Piece p) {
    return static_cast<PieceType>(p % 6);
}

constexpr Color color_of(Piece p) {
    return static_cast<Color>(p / 6);
}

// Squares: 0 = A1, 7 = H1, ..., 56 = A8, 63 = H8
enum Square : int {
    SQ_A1 = 0,  SQ_B1, SQ_C1, SQ_D1, SQ_E1, SQ_F1, SQ_G1, SQ_H1,
    SQ_A2, SQ_B2, SQ_C2, SQ_D2, SQ_E2, SQ_F2, SQ_G2, SQ_H2,
    SQ_A3, SQ_B3, SQ_C3, SQ_D3, SQ_E3, SQ_F3, SQ_G3, SQ_H3,
    SQ_A4, SQ_B4, SQ_C4, SQ_D4, SQ_E4, SQ_F4, SQ_G4, SQ_H4,
    SQ_A5, SQ_B5, SQ_C5, SQ_D5, SQ_E5, SQ_F5, SQ_G5, SQ_H5,
    SQ_A6, SQ_B6, SQ_C6, SQ_D6, SQ_E6, SQ_F6, SQ_G6, SQ_H6,
    SQ_A7, SQ_B7, SQ_C7, SQ_D7, SQ_E7, SQ_F7, SQ_G7, SQ_H7,
    SQ_A8, SQ_B8, SQ_C8, SQ_D8, SQ_E8, SQ_F8, SQ_G8, SQ_H8,
    SQ_NONE = 64,
    SQUARE_NB = 64
};

constexpr Square make_square(int file, int rank) {
    return static_cast<Square>((rank << 3) + file);
}

constexpr int file_of(Square sq) {
    return sq & 7;
}

constexpr int rank_of(Square sq) {
    return sq >> 3;
}

constexpr Square flip_square(Square sq) {
    return static_cast<Square>(sq ^ 56);
}

// Castling rights flags
enum CastlingRights : uint8_t {
    NO_CASTLING = 0,
    WHITE_OO = 1,
    WHITE_OOO = 2,
    BLACK_OO = 4,
    BLACK_OOO = 8,
    WHITE_ANY = WHITE_OO | WHITE_OOO,
    BLACK_ANY = BLACK_OO | BLACK_OOO,
    ANY_CASTLING = WHITE_ANY | BLACK_ANY
};

// Evaluation and Search values
enum Value : int {
    VALUE_ZERO = 0,
    VALUE_DRAW = 0,
    VALUE_MATE = 30000,
    VALUE_MATE_IN_MAX = VALUE_MATE - 256,
    VALUE_INFINITE = 32000,
    VALUE_NONE = 32001
};

// Move representation: 16-bit integer
// bits 0-5: from square (0-63)
// bits 6-11: to square (0-63)
// bits 12-13: promotion piece type (0=KNIGHT, 1=BISHOP, 2=ROOK, 3=QUEEN)
// bits 14-15: move flag (0=NORMAL, 1=PROMOTION, 2=EN_PASSANT, 3=CASTLING)
enum MoveFlag : uint16_t {
    FLAG_NORMAL = 0x0000,
    FLAG_PROMOTION = 0x4000,
    FLAG_EN_PASSANT = 0x8000,
    FLAG_CASTLING = 0xC000
};

struct Move {
    uint16_t data;

    constexpr Move() : data(0) {}
    constexpr explicit Move(uint16_t d) : data(d) {}
    constexpr Move(Square from, Square to, MoveFlag flag = FLAG_NORMAL, PieceType promo = KNIGHT)
        : data(static_cast<uint16_t>(from | (to << 6) | (flag) | ((promo - KNIGHT) << 12))) {}

    constexpr Square from() const { return static_cast<Square>(data & 0x3F); }
    constexpr Square to() const { return static_cast<Square>((data >> 6) & 0x3F); }
    constexpr MoveFlag flag() const { return static_cast<MoveFlag>(data & 0xC000); }
    constexpr PieceType promotion_type() const {
        return static_cast<PieceType>(((data >> 12) & 0x3) + KNIGHT);
    }

    constexpr bool is_promotion() const { return (data & 0xC000) == FLAG_PROMOTION; }
    constexpr bool is_en_passant() const { return (data & 0xC000) == FLAG_EN_PASSANT; }
    constexpr bool is_castling() const { return (data & 0xC000) == FLAG_CASTLING; }
    constexpr bool is_null() const { return data == 0; }

    constexpr bool operator==(const Move& other) const { return data == other.data; }
    constexpr bool operator!=(const Move& other) const { return data != other.data; }

    std::string to_uci() const {
        if (is_null()) return "0000";
        std::string s;
        s += static_cast<char>('a' + file_of(from()));
        s += static_cast<char>('1' + rank_of(from()));
        s += static_cast<char>('a' + file_of(to()));
        s += static_cast<char>('1' + rank_of(to()));
        if (is_promotion()) {
            switch (promotion_type()) {
                case QUEEN: s += 'q'; break;
                case ROOK: s += 'r'; break;
                case BISHOP: s += 'b'; break;
                case KNIGHT: s += 'n'; break;
                default: break;
            }
        }
        return s;
    }
};

constexpr Move MOVE_NONE = Move(0);

// Simple MoveList struct with fixed stack allocation for speed
struct MoveList {
    Move moves[256];
    int scores[256];
    int size = 0;

    void add(Move m, int score = 0) {
        moves[size] = m;
        scores[size] = score;
        size++;
    }

    void clear() { size = 0; }
};

#endif // TYPES_H
