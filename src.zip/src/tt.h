#ifndef TT_H
#define TT_H

#include "types.h"
#include <vector>
#include <cstdint>

enum TTFlag : uint8_t {
    TT_EXACT = 0,
    TT_LOWERBOUND = 1,
    TT_UPPERBOUND = 2
};

struct TTEntry {
    Key key = 0;
    int16_t score = 0;
    int8_t depth = 0;
    uint8_t flag = 0;
    uint8_t age = 0;
    Move best_move = MOVE_NONE;
};

class TranspositionTable {
public:
    TranspositionTable();
    ~TranspositionTable();

    void resize(size_t mb);
    void clear();
    void new_search() { current_age++; }

    bool probe(Key key, int depth, int alpha, int beta, int ply, int& out_score, Move& out_move) const;
    void store(Key key, int depth, int score, TTFlag flag, int ply, Move best_move);

    int hashfull() const; // Per mill (0..1000)

private:
    std::vector<TTEntry> table;
    size_t num_entries = 0;
    uint8_t current_age = 0;
};

extern TranspositionTable TT;

#endif // TT_H
