#ifndef NNUE_H
#define NNUE_H

#include "types.h"
#include "board.h"
#include <string>
#include <cstdint>

constexpr int NNUE_INPUTS = 768; // 12 pieces * 64 squares
constexpr int NNUE_HIDDEN = 256;
constexpr int NNUE_OUTPUTS = 1;
constexpr int NNUE_SCALE = 400;

struct NNUEWeights {
    int16_t ft_biases[NNUE_HIDDEN];
    int16_t ft_weights[NNUE_INPUTS * NNUE_HIDDEN];
    int32_t out_bias;
    int16_t out_weights[NNUE_HIDDEN * 2];
};

extern NNUEWeights GLOBAL_NNUE;
extern bool NNUE_LOADED;

bool load_nnue(const std::string& filepath);
bool save_nnue(const std::string& filepath);
void init_default_nnue();
bool is_nnue_loaded();

// Evaluation function
int evaluate_nnue(const Board& board);

// Feature indexing helper
inline int get_feature_index(Color perspective, Piece piece, Square sq) {
    Color p_color = color_of(piece);
    PieceType pt = type_of(piece);

    int piece_idx;
    Square mapped_sq;

    if (perspective == WHITE) {
        piece_idx = (p_color == WHITE) ? pt : (pt + 6);
        mapped_sq = sq;
    } else {
        piece_idx = (p_color == BLACK) ? pt : (pt + 6);
        mapped_sq = flip_square(sq);
    }

    return piece_idx * 64 + mapped_sq;
}

#endif // NNUE_H
